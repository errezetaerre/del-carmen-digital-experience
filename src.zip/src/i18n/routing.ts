import { defineRouting } from "next-intl/routing";
import { defaultLocale, locales } from "./config";

export const routing = defineRouting({
    locales,
    defaultLocale,
    localePrefix: "as-needed",
    localeDetection: false,
    localeCookie: false,
    // Enable alternates after the complete Spanish content/domain review.
    alternateLinks: false,
});
