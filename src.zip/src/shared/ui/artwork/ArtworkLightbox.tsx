"use client";
import { useLocale, useTranslations } from "next-intl";
import { artworkTextLocale, formatArtworkTechnique, localizeArtwork } from "@/i18n/artworkCopy";
import { createPortal } from "react-dom";

import Link from "@/i18n/navigation";
import ArtworkLinkFeedback from "./ArtworkLinkFeedback";

import {
    useCallback,
    type SetStateAction,
    useEffect,
    useLayoutEffect,
    useId,
    useRef,
    useState,
    useMemo,
} from "react";

import type { Artwork } from "@/domains/artworks/model";
import styles from "./ArtworkLightbox.module.css";
import ArtworkImageHighlights from "./ArtworkImageHighlights";
import ArtworkArrivalAccent from "./ArtworkArrivalEffect";
import ArtworkComingSoon from "./ArtworkComingSoon";
import { getArtworkPresentation } from "@/domains/artworks/presentation/getArtworkPresentation";
import GlassArtworkFrame from "./GlassArtworkFrame";
import { glassSeparatorMarkup } from "./glassAccents";
import { InteractionHint } from "@/shared/ui/interaction-hint";
import useDialogFocus from "@/shared/hooks/useDialogFocus";
import ArtworkReadingPanel from "./ArtworkReadingPanel";
import ArtworkViewerEditorial from "./ArtworkViewerEditorial";
import { bindArtworkStandardNavigation, type ArtworkStandardNavigation } from "./artworkStandardNavigation";
import { ARTWORK_KINETICS } from "./artworkKinetics";
import ArtworkDetailViewer from "@/domains/artworks/components/ArtworkDetailViewer";
import { hasBlockingArtworkDialog } from "./hasBlockingArtworkDialog";

export interface ArtworkLightboxProps {
    artworks: Artwork[];
    initialIndex: number;
    isOpen: boolean;
    onClose: () => void;
    embedded?: boolean;
    onIndexChange?: (index: number) => void;
    layout?: "portrait" | "landscape";
    onReady?: () => void;

    showDetailsCta?: boolean;
    showAllWorksCta?: boolean;

    detailsCtaLabel?: string;
    detailsQuery?: string;
    presentation?: "standard" | "glass";
}

type Point = {
    x: number;
    y: number;
};

type PanGesture = {
    startX: number;
    startY: number;
    startPanX: number;
    startPanY: number;
};

type PinchGesture = {
    startDistance: number;
    startScale: number;
    startCenterX: number;
    startCenterY: number;
    startPanX: number;
    startPanY: number;
};

const SWIPE_THRESHOLD = 55;

const MIN_SCALE = 1;
const MAX_SCALE = 3;
const SNAP_SCALE = 1.03;

export default function ArtworkLightbox({
    artworks: sourceArtworks,
    initialIndex,
    isOpen,
    onClose,

    showDetailsCta = false,
    showAllWorksCta = true,

    detailsCtaLabel = "View details",
    detailsQuery,
    presentation = "standard",
    embedded = false,
    onIndexChange,
    layout = "portrait",
    onReady,
}: ArtworkLightboxProps) {
    const locale = useLocale();
    const t = useTranslations("Artwork");
    const artworks = useMemo(() => sourceArtworks.map((item) => localizeArtwork(item, locale)), [sourceArtworks, locale]);
    const detailsLabel = locale === "en" ? detailsCtaLabel : detailsCtaLabel === "Explore in detail" ? t("exploreDetail") : detailsCtaLabel === "View details" ? t("viewDetails") : detailsCtaLabel;
    /* =========================================================
       STATE
       ========================================================= */

    const [internalIndex, setInternalIndex] = useState(initialIndex);
    const currentIndex = onIndexChange ? initialIndex : internalIndex;
    const setCurrentIndex = useCallback((next: SetStateAction<number>) => {
        if (onIndexChange) onIndexChange(typeof next === "function" ? next(initialIndex) : next);
        else setInternalIndex(next);
    }, [initialIndex, onIndexChange]);

    const [swipeHintDismissed, setSwipeHintDismissed] =
        useState(false);

    const [openingSource, setOpeningSource] = useState({ isOpen, initialIndex });
    if (openingSource.isOpen !== isOpen || openingSource.initialIndex !== initialIndex) {
        setOpeningSource({ isOpen, initialIndex });
        if (isOpen) {
            if (!onIndexChange) setInternalIndex(initialIndex);
            if (!openingSource.isOpen) setSwipeHintDismissed(false);
        }
    }

    const isGlass = presentation === "glass";
    const instanceId = `artwork${useId().replace(/[^a-zA-Z0-9_-]/g, "")}`;
    const [descriptionExpanded, setDescriptionExpanded] = useState(false);
    const [descriptionOverflows, setDescriptionOverflows] = useState(false);
    const descriptionRef = useRef<HTMLParagraphElement>(null);
    const descriptionButtonRef = useRef<HTMLButtonElement>(null);
    const descriptionExpandedRef = useRef(false);
    useLayoutEffect(() => { descriptionExpandedRef.current = descriptionExpanded; }, [descriptionExpanded]);
    const swipeAxisRef = useRef<"pending" | "horizontal" | "vertical">("pending");
    const navigationRef = useRef<ArtworkStandardNavigation | null>(null);
    const viewportRef = useRef<HTMLDivElement>(null);
    const imageGestureRootRef = useRef<HTMLDivElement>(null);
    const navigationOptions = useRef<{ navigate(direction: -1 | 1): void; zoomed(): boolean; onInteraction(): void }>({ navigate: () => {}, zoomed: () => false, onInteraction: () => {} });

    /* =========================================================
       REFS
       ========================================================= */

    const closeButtonRef =
        useRef<HTMLButtonElement | null>(null);

    const zoomLayerRef =
        useRef<HTMLDivElement | null>(null);

    const activePointersRef =
        useRef<Map<number, Point>>(
            new Map(),
        );

    const swipeStartRef =
        useRef<Point | null>(null);

    const panGestureRef =
        useRef<PanGesture | null>(null);

    const pinchGestureRef =
        useRef<PinchGesture | null>(null);

    const scaleRef =
        useRef(1);

    const panXRef =
        useRef(0);

    const panYRef =
        useRef(0);

    const hadMultiTouchRef =
        useRef(false);

    /* =========================================================
       DATA
       ========================================================= */

    const artwork =
        artworks[currentIndex];

    const total =
        artworks.length;

    const hasHighlights = artwork ? getArtworkPresentation(artwork, locale).badges.some((badge) => badge.kind !== "planned" && badge.kind !== "in-progress") : false;
    const nativeScroll = isGlass || hasHighlights;

    const primaryImage =
        artwork?.images.primary;
    useEffect(() => {
        if (!isOpen || !onReady) return;
        const image = zoomLayerRef.current?.querySelector<HTMLImageElement>("img");
        let active = true;
        const ready = () => { if (active) onReady(); };
        if (!image) ready();
        else if (image.complete) void image.decode().catch(() => {}).then(ready);
        else { image.addEventListener("load", ready); image.addEventListener("error", ready); }
        return () => { active = false; image?.removeEventListener("load", ready); image?.removeEventListener("error", ready); };
    }, [artwork?.id, isOpen, onReady]);
    const dialogRef = useRef<HTMLDivElement>(null);
    useDialogFocus(dialogRef, !embedded && isOpen && Boolean(artwork && primaryImage), { initialFocusRef: closeButtonRef });

    const readingKey = JSON.stringify([isOpen, isGlass, artwork?.id, artwork?.description]);
    const [previousReadingKey, setPreviousReadingKey] = useState(readingKey);
    if (previousReadingKey !== readingKey) {
        setPreviousReadingKey(readingKey);
        setDescriptionExpanded(false);
    }

    useEffect(() => {
        const text = descriptionRef.current;
        if (!isOpen || !isGlass || !text) {
            setDescriptionOverflows(false);
            return;
        }
        let disposed = false;
        const measure = () => {
            if (!disposed) setDescriptionOverflows(text.clientHeight === 0 ? Boolean(artwork?.description?.trim()) : text.scrollHeight > text.clientHeight + 1);
        };
        const observer = new ResizeObserver(measure);
        observer.observe(text);
        measure();
        document.fonts?.ready.then(measure);
        document.fonts?.addEventListener("loadingdone", measure);
        return () => {
            disposed = true;
            observer.disconnect();
            document.fonts?.removeEventListener("loadingdone", measure);
        };
    }, [isOpen, isGlass, artwork?.id, artwork?.description]);

    /* =========================================================
       HELPERS
       ========================================================= */

    const clamp = (
        value: number,
        min: number,
        max: number,
    ) => {
        return Math.min(
            Math.max(value, min),
            max,
        );
    };

    const getDistance = (
        a: Point,
        b: Point,
    ) => {
        return Math.hypot(
            b.x - a.x,
            b.y - a.y,
        );
    };

    const getCenter = (
        a: Point,
        b: Point,
    ) => {
        return {
            x: (a.x + b.x) / 2,
            y: (a.y + b.y) / 2,
        };
    };

    const clampPan = (
        x: number,
        y: number,
        scale: number,
    ) => {
        const layer =
            zoomLayerRef.current;

        if (
            !layer ||
            scale <= 1
        ) {
            return {
                x: 0,
                y: 0,
            };
        }

        const width =
            layer.offsetWidth;

        const height =
            layer.offsetHeight;

        const maxX =
            (width * (scale - 1)) / 2;

        const maxY =
            (height * (scale - 1)) / 2;

        return {
            x: clamp(
                x,
                -maxX,
                maxX,
            ),

            y: clamp(
                y,
                -maxY,
                maxY,
            ),
        };
    };

    const applyTransform = (
        scale = scaleRef.current,
        x = panXRef.current,
        y = panYRef.current,
        animate = false,
    ) => {
        const layer =
            zoomLayerRef.current;

        if (!layer) {
            return;
        }

        const safeScale =
            clamp(
                scale,
                MIN_SCALE,
                MAX_SCALE,
            );

        const safePan =
            clampPan(
                x,
                y,
                safeScale,
            );

        scaleRef.current =
            safeScale;

        panXRef.current =
            safePan.x;

        panYRef.current =
            safePan.y;

        if (nativeScroll) layer.style.touchAction = safeScale <= SNAP_SCALE ? "pan-y" : "none";

        layer.style.transition =
            animate
                ? "transform 260ms cubic-bezier(0.22, 0.61, 0.36, 1)"
                : "none";

        layer.style.transform = `
      translate3d(
        ${safePan.x}px,
        ${safePan.y}px,
        0
      )
      scale(${safeScale})
    `;
    };

    const resetZoom = (
        animate = true,
    ) => {
        scaleRef.current = 1;

        panXRef.current = 0;
        panYRef.current = 0;

        panGestureRef.current =
            null;

        pinchGestureRef.current =
            null;

        applyTransform(
            1,
            0,
            0,
            animate,
        );
    };

    useLayoutEffect(() => {
        navigationOptions.current = {
            navigate: direction => { resetZoom(false); setCurrentIndex(index => (index + direction + total) % total); },
            zoomed: () => scaleRef.current > SNAP_SCALE || descriptionExpandedRef.current || Boolean(viewportRef.current?.querySelector("[data-artwork-reading-open]")),
            onInteraction: () => setSwipeHintDismissed(true),
        };
    });
    useLayoutEffect(() => {
        if (!embedded || !isGlass || !isOpen || total < 2 || !viewportRef.current) return;
        const track = viewportRef.current.querySelector<HTMLElement>("[data-standard-track]");
        if (!track) return;
        const controller = bindArtworkStandardNavigation(viewportRef.current, track, {
            navigate: direction => navigationOptions.current.navigate(direction),
            zoomed: () => navigationOptions.current.zoomed(),
            onInteraction: () => navigationOptions.current.onInteraction(),
        });
        navigationRef.current = controller;
        return () => { controller.dispose(); navigationRef.current = null; };
    }, [embedded, isGlass, isOpen, total]);
    useLayoutEffect(() => { navigationRef.current?.selectionChanged(); }, [currentIndex, artwork?.id]);

    useEffect(() => {
        const viewport = viewportRef.current;
        if (!isOpen || !viewport) return;
        // A pinch hands its touches to the image viewer. Their release may
        // never bubble back to this adapter, so no finger may remain cached.
        const clearImageInput = () => {
            activePointersRef.current.clear();
            swipeStartRef.current = null; swipeAxisRef.current = "pending";
            panGestureRef.current = null; pinchGestureRef.current = null;
            hadMultiTouchRef.current = false;
        };
        viewport.addEventListener("artwork-image-zoom", clearImageInput);
        return () => viewport.removeEventListener("artwork-image-zoom", clearImageInput);
    }, [isOpen]);

    /* =========================================================
       RESET WHEN OPENING
       ========================================================= */

    useEffect(() => {
        activePointersRef.current.clear();

        swipeStartRef.current =
            null;

        panGestureRef.current =
            null;

        pinchGestureRef.current =
            null;

        hadMultiTouchRef.current =
            false;

        scaleRef.current = 1;

        panXRef.current = 0;
        panYRef.current = 0;

        const layer =
            zoomLayerRef.current;

        if (layer) {
            layer.style.transition =
                "none";

            layer.style.transform =
                "translate3d(0px, 0px, 0) scale(1)";
        }
    }, [currentIndex]);

    /* =========================================================
       BODY LOCK + KEYBOARD
       ========================================================= */

    useEffect(() => {
        if (!isOpen) {
            return;
        }

        const originalOverflow =
            document.body.style.overflow;

        if (!embedded) {
            document.body.style.overflow = "hidden";
            closeButtonRef.current?.focus();
        }

        const handleKeyDown = (
            event: KeyboardEvent,
        ) => {
            if (event.defaultPrevented || (viewportRef.current && hasBlockingArtworkDialog(viewportRef.current))) return;
            if (isGlass && event.key === "Escape" && descriptionExpandedRef.current) {
                event.preventDefault();
                setDescriptionExpanded(false);
                descriptionButtonRef.current?.focus();
                return;
            }
            if (isGlass && event.target instanceof HTMLElement && event.target.closest("[data-lightbox-native-scroll]")) {
                return;
            }
            if (
                event.key ===
                "Escape"
            ) {
                onClose();
            }

            if (
                event.key ===
                "ArrowRight"
            ) {
                if (navigationRef.current) { event.preventDefault(); navigationRef.current.navigate(1); return; }
                setCurrentIndex(
                    (index) =>
                        (index + 1) %
                        total,
                );
            }

            if (
                event.key ===
                "ArrowLeft"
            ) {
                if (navigationRef.current) { event.preventDefault(); navigationRef.current.navigate(-1); return; }
                setCurrentIndex(
                    (index) =>
                        (index - 1 + total) %
                        total,
                );
            }
        };

        window.addEventListener(
            "keydown",
            handleKeyDown,
        );

        return () => {
            if (!embedded) document.body.style.overflow = originalOverflow;

            window.removeEventListener(
                "keydown",
                handleKeyDown,
            );
        };
    }, [
        isOpen,
        onClose,
        total,
        isGlass,
        embedded,
        setCurrentIndex,
    ]);

    /* =========================================================
       SWIPE INTRODUCTION
       ========================================================= */

    const dismissSwipeHint = () => {
        setSwipeHintDismissed(true);
    };

    /* =========================================================
       RENDER GUARD
       ========================================================= */

    if (
        !isOpen ||
        !artwork ||
        !primaryImage
    ) {
        return null;
    }

    /* =========================================================
       ORIENTATION
       ========================================================= */

    const isPortrait =
        artwork.dimensions.height >
        artwork.dimensions.width;

    /* =========================================================
       NAVIGATION
       ========================================================= */

    const goNext = () => {
        if (navigationRef.current) { navigationRef.current.navigate(1); return; }
        resetZoom(false);

        setCurrentIndex(
            (index) =>
                (index + 1) %
                total,
        );
    };

    const goPrevious = () => {
        if (navigationRef.current) { navigationRef.current.navigate(-1); return; }
        resetZoom(false);

        setCurrentIndex(
            (index) =>
                (index - 1 + total) %
                total,
        );
    };

    const handleBackdropClick = (
        event: React.MouseEvent<HTMLDivElement>,
    ) => {
        const target = event.target as HTMLElement;

        if (
            target.closest(
                "a, button, [data-lightbox-content='true'], [data-artwork-dragging]",
            )
        ) {
            return;
        }

        onClose();
    };

    /* =========================================================
       POINTER DOWN
       ========================================================= */

    const handlePointerDown = (
        event: React.PointerEvent<HTMLDivElement>,
    ) => {
        if (
            event.pointerType !==
            "touch" &&
            event.pointerType !==
            "pen"
        ) {
            return;
        }

        if (isGlass && (event.target as HTMLElement).closest("[data-lightbox-native-scroll], [data-artwork-reading-open]")) return;
        if ((event.target as HTMLElement).closest("a, button, [data-artwork-highlights]")) return;
        dismissSwipeHint();

        const pointers =
            activePointersRef.current;

        pointers.set(
            event.pointerId,
            {
                x: event.clientX,
                y: event.clientY,
            },
        );

        try {
            if (!nativeScroll || scaleRef.current > SNAP_SCALE || pointers.size >= 2) {
                for (const id of pointers.keys()) event.currentTarget.setPointerCapture(id);
            }
        } catch {
            // Pointer capture may not be available.
        }

        if (
            pointers.size === 1
        ) {
            navigationRef.current?.begin();
            swipeAxisRef.current = "pending";
            hadMultiTouchRef.current =
                false;

            swipeStartRef.current = {
                x: event.clientX,
                y: event.clientY,
            };

            panGestureRef.current = {
                startX:
                    event.clientX,

                startY:
                    event.clientY,

                startPanX:
                    panXRef.current,

                startPanY:
                    panYRef.current,
            };

            return;
        }

        if (
            pointers.size === 2
        ) {
            navigationRef.current?.reset();
            hadMultiTouchRef.current =
                true;

            swipeStartRef.current =
                null;

            const [
                first,
                second,
            ] = Array.from(
                pointers.values(),
            );

            const center =
                getCenter(
                    first,
                    second,
                );

            pinchGestureRef.current = {
                startDistance:
                    getDistance(
                        first,
                        second,
                    ),

                startScale:
                    scaleRef.current,

                startCenterX:
                    center.x,

                startCenterY:
                    center.y,

                startPanX:
                    panXRef.current,

                startPanY:
                    panYRef.current,
            };
        }
    };

    /* =========================================================
       POINTER MOVE
       ========================================================= */

    const handlePointerMove = (
        event: React.PointerEvent<HTMLDivElement>,
    ) => {
        const pointers =
            activePointersRef.current;

        if (
            !pointers.has(
                event.pointerId,
            )
        ) {
            return;
        }

        pointers.set(
            event.pointerId,
            {
                x: event.clientX,
                y: event.clientY,
            },
        );

        if (nativeScroll && pointers.size === 1 && scaleRef.current <= SNAP_SCALE && swipeStartRef.current) {
            const dx = event.clientX - swipeStartRef.current.x;
            const dy = event.clientY - swipeStartRef.current.y;
            if (swipeAxisRef.current === "pending") {
                if (Math.max(Math.abs(dx), Math.abs(dy)) < ARTWORK_KINETICS.intentDistance) return;
                if (Math.abs(dx) < Math.abs(dy) * ARTWORK_KINETICS.axisLockRatio) {
                    navigationRef.current?.reset();
                    swipeAxisRef.current = "vertical";
                    swipeStartRef.current = null;
                    panGestureRef.current = null;
                    pointers.delete(event.pointerId);
                    try { event.currentTarget.releasePointerCapture(event.pointerId); } catch {}
                    return;
                }
                swipeAxisRef.current = "horizontal";
                try { event.currentTarget.setPointerCapture(event.pointerId); } catch {}
            }
            if (swipeAxisRef.current === "horizontal") navigationRef.current?.preview(dx);
        }

        /* Pinch */

        if (
            pointers.size >= 2 &&
            pinchGestureRef.current
        ) {
            const [
                first,
                second,
            ] = Array.from(
                pointers.values(),
            );

            const gesture =
                pinchGestureRef.current;

            const distance =
                getDistance(
                    first,
                    second,
                );

            const center =
                getCenter(
                    first,
                    second,
                );

            const ratio =
                distance /
                gesture.startDistance;

            const nextScale =
                clamp(
                    gesture.startScale *
                    ratio,

                    MIN_SCALE,
                    MAX_SCALE,
                );

            const centerDeltaX =
                center.x -
                gesture.startCenterX;

            const centerDeltaY =
                center.y -
                gesture.startCenterY;

            const nextPanX =
                gesture.startPanX +
                centerDeltaX;

            const nextPanY =
                gesture.startPanY +
                centerDeltaY;

            applyTransform(
                nextScale,
                nextPanX,
                nextPanY,
            );

            return;
        }

        /* Pan */

        if (
            pointers.size === 1 &&
            scaleRef.current >
            SNAP_SCALE &&
            panGestureRef.current
        ) {
            const gesture =
                panGestureRef.current;

            const nextPanX =
                gesture.startPanX +
                event.clientX -
                gesture.startX;

            const nextPanY =
                gesture.startPanY +
                event.clientY -
                gesture.startY;

            applyTransform(
                scaleRef.current,
                nextPanX,
                nextPanY,
            );
        }
    };

    /* =========================================================
       POINTER UP
       ========================================================= */

    const handlePointerUp = (
        event: React.PointerEvent<HTMLDivElement>,
    ) => {
        const pointers =
            activePointersRef.current;

        const releasedPoint =
            pointers.get(
                event.pointerId,
            );

        pointers.delete(
            event.pointerId,
        );

        try {
            event.currentTarget.releasePointerCapture(
                event.pointerId,
            );
        } catch {
            // Already released.
        }

        if (
            hadMultiTouchRef.current
        ) {
            pinchGestureRef.current =
                null;

            if (
                scaleRef.current <=
                SNAP_SCALE
            ) {
                resetZoom(true);
            }

            if (
                pointers.size === 1
            ) {
                const remaining =
                    Array.from(
                        pointers.values(),
                    )[0];

                panGestureRef.current = {
                    startX:
                        remaining.x,

                    startY:
                        remaining.y,

                    startPanX:
                        panXRef.current,

                    startPanY:
                        panYRef.current,
                };
            }

            if (
                pointers.size === 0
            ) {
                hadMultiTouchRef.current =
                    false;

                panGestureRef.current =
                    null;
            }

            return;
        }

        if (
            scaleRef.current >
            SNAP_SCALE
        ) {
            panGestureRef.current =
                null;

            return;
        }

        if (
            !releasedPoint ||
            !swipeStartRef.current
        ) {
            return;
        }

        const distance =
            releasedPoint.x -
            swipeStartRef.current.x;

        swipeStartRef.current =
            null;

        panGestureRef.current =
            null;

        if (navigationRef.current) { navigationRef.current.release(); return; }

        if (
            Math.abs(distance) <
            SWIPE_THRESHOLD
        ) {
            return;
        }

        if (
            distance < 0
        ) {
            goNext();
        } else {
            goPrevious();
        }
    };

    /* =========================================================
       POINTER CANCEL
       ========================================================= */

    const handlePointerCancel = (
        event: React.PointerEvent<HTMLDivElement>,
    ) => {
        navigationRef.current?.reset();
        activePointersRef.current.delete(
            event.pointerId,
        );

        swipeStartRef.current =
            null;

        panGestureRef.current =
            null;

        pinchGestureRef.current =
            null;

        hadMultiTouchRef.current =
            false;

        if (
            scaleRef.current <=
            SNAP_SCALE
        ) {
            resetZoom(true);
        }
    };

    /* =========================================================
       RENDER
       ========================================================= */

    const Panel = isGlass ? GlassArtworkFrame : "div";

    const renderPositionDots = (selectedIndex: number) => (
                    total > 1 && (
                        <div
                            data-lightbox-position-dots
                            className={isGlass ? styles.positionDots : `${styles.standardDots} relative z-40 flex h-5 shrink-0 items-center justify-center gap-2 md:h-6 [@media(orientation:landscape)_and_(max-height:600px)]:h-4`}
                            aria-label={t("position", { index: selectedIndex + 1, total })}
                        >
                            {artworks.map((item, index) => {
                                const isActive = index === selectedIndex;

                                return (
                                    <button
                                        key={item.id}
                                        data-artwork-arrival-navigation
                                        type="button"
                                        onClick={() => {
                                            resetZoom(false);
                                            setCurrentIndex(index);
                                        }}
                                        onPointerDown={(event) => event.stopPropagation()}
                                        aria-label={t("viewArtwork", { index: index + 1 })}
                                        aria-current={isActive ? "true" : undefined}
                                        className="group flex h-5 w-5 items-center justify-center focus-visible:outline-none"
                                    >
                                        <span
                                            className={[
                                                "block h-[5px] w-[5px] rounded-full border transition-all duration-300",
                                                isActive
                                                    ? "scale-110 border-white/80 bg-white/80"
                                                    : "border-white/35 bg-transparent group-hover:border-white/65",
                                            ].join(" ")}
                                        />
                                    </button>
                                );
                            })}
                        </div>
                    )
    );

    const positionDots = renderPositionDots(currentIndex);

    // All three slots use the same artwork markup; only Current owns controls,
    // reading state, zoom refs, guidance and the arrival decoration.
    function renderPanel(artwork: Artwork, frameIndex: number, slot: "previous" | "current" | "next" = "current") {
        const active = slot === "current";
        const primaryImage = artwork.images.primary;
        const hasHighlights = active && getArtworkPresentation(artwork, locale).badges.some(badge => badge.kind !== "planned" && badge.kind !== "in-progress");
        const techniqueLabel = locale === "en" ? `${artwork.medium} on ${artwork.support}` : formatArtworkTechnique(artwork, locale);
        const detailsHref = `/artworks/${artwork.slug}${detailsQuery ? `?${detailsQuery}` : ""}`;
        const frameDescriptionExpanded = active && descriptionExpanded;
        const frameId = `${instanceId}-${slot}`;
        const positionDots = renderPositionDots(frameIndex);
        return (
                <Panel data-lightbox-content={isGlass ? "true" : undefined} data-lightbox-panel data-standard-frame={embedded && active || undefined} data-standard-preview-frame={embedded && !active || undefined} data-standard-artwork={embedded ? artwork.id : undefined} data-lightbox-layout={layout}
                    className={isGlass ? styles.panelLayout : `${styles.standardPanel} relative flex h-[calc(100svh-24px)] w-full max-w-[1040px] flex-col lg:translate-x-[1.5vw] md:h-[min(90vh,900px)] [@media(orientation:landscape)_and_(max-height:600px)]:h-[calc(100svh-16px)] [@media(orientation:landscape)_and_(max-height:600px)]:max-w-none [@media(orientation:landscape)_and_(max-height:600px)]:translate-x-0`}
                >
                    {embedded && layout === "portrait" ? <div className={styles.panelInterior} data-lightbox-interior>
                        <ArtworkViewerEditorial key={artwork.id} artwork={artwork} portalTarget={null}
                            standard active={active} positionDots={positionDots} zoomLayerRef={active ? zoomLayerRef : undefined} detailsQuery={detailsQuery}
                            detailsLabel={detailsLabel} showDetails={showDetailsCta} showAllWorks={showAllWorksCta}
                            readingExpanded={frameDescriptionExpanded} onReadingChange={active ? setDescriptionExpanded : undefined}
                            hint={<InteractionHint active={isOpen && active} dismissed={swipeHintDismissed} label={t("swipe")} visibility="coarse" />} />
                    </div> : <>
                    <div className={embedded ? styles.panelInterior : styles.legacyInterior} data-lightbox-interior={embedded || undefined}>
                    <div className={embedded ? styles.panelContent : styles.legacyInterior}>
                    {/* Artwork stage */}
                    <div data-artwork-reading-boundary className={isGlass ? styles.artworkStage : "relative flex min-h-0 flex-1 items-center justify-center px-7 pb-2 pt-12 md:px-10 md:pb-3 md:pt-8 [@media(orientation:landscape)_and_(max-height:600px)]:px-12 [@media(orientation:landscape)_and_(max-height:600px)]:pb-1 [@media(orientation:landscape)_and_(max-height:600px)]:pt-3"}>
                        {/* Glow belongs to the artwork, not the canvas */}
                        <div
                            aria-hidden
                            className={isGlass ? styles.artworkAura : "pointer-events-none fixed left-1/2 top-1/2 h-[78%] w-[72%] -translate-x-1/2 -translate-y-1/2 rounded-[32px] bg-[radial-gradient(ellipse_at_center,rgba(198,151,79,0.16)_0%,rgba(198,151,79,0.07)_36%,transparent_72%)] blur-[28px] [@media(orientation:landscape)_and_(max-height:600px)]:h-[94%] [@media(orientation:landscape)_and_(max-height:600px)]:w-[88%]"}
                        />

                        {/* Zoomable artwork — no visible frame/border */}
                        <ArtworkImageHighlights artwork={artwork} className={isGlass ? styles.imageWrapper : "relative h-full max-h-full w-full max-w-full lg:translate-x-[1.5vw] items-center justify-center"}>
                            <div ref={active ? imageGestureRootRef : undefined} className={isGlass ? styles.imageMask : "contents"}>
                            <div
                                ref={active ? zoomLayerRef : undefined}
                                data-artwork-arrival-zoom
                                data-lightbox-content="true"
                                className={isGlass ? styles.zoomViewport : "relative flex h-full max-h-full w-full max-w-full origin-center items-center justify-center overflow-hidden will-change-transform"}
                            >
                                {artwork.creationStatus !== "completed" ? <ArtworkComingSoon artwork={artwork} /> : <img
                                    key={artwork.id}
                                    data-artwork-arrival-photo
                                    src={primaryImage.src}
                                    alt={primaryImage.alt}
                                    draggable={false}
                                    className={isGlass ? styles.primaryImage : "relative z-10 h-full max-h-full w-full max-w-full translate-x-[5.5vw] select-none object-contain"}
                                />}

                                {/* Subtle image-only integration */}
                                <div
                                    aria-hidden
                                    className={isGlass ? styles.imageShade : "pointer-events-none fixed inset-0 z-20 shadow-[inset_0_0_42px_10px_rgba(0,0,0,0.28)]"}
                                />

                                {/* Image-only moving reflection */}
                                <div
                                    aria-hidden
                                    className={isGlass ? styles.imageReflection : "artwork-glass-reflection pointer-events-none fi xed -left-[30%] -top-[20%] z-30 h-[140%] w-[24%] rotate-[14deg] bg-gradient-to-r from-transparent via-white/[0.045] to-transparent blur-[10px]"}
                                />
                            </div>
                            </div>
                            {hasHighlights && artwork.creationStatus === "completed" && <ArtworkArrivalAccent key={artwork.id} artworkId={artwork.id} surface="lightbox" />}
                        </ArtworkImageHighlights>
                        {active && <ArtworkDetailViewer artwork={artwork} triggerOnly gestureRoot={imageGestureRootRef} />}


                        {/* Ephemeral touch guidance — shared interaction language */}
                        <InteractionHint
                            active={isOpen && active}
                            dismissed={swipeHintDismissed}
                            label={t("swipe")}
                            visibility="coarse"
                        />
                    </div>

                    {(!embedded || layout !== "landscape") && positionDots}

                    {/* Information panel */}
                    <div
                        data-lightbox-content="true"
                        data-lightbox-caption
                        data-description-expanded={frameDescriptionExpanded || undefined}
                        inert={frameDescriptionExpanded}
                        className={isGlass ? styles.caption : "relative z-30 w-full shrink-0 px-5 pb-4 pt-3 text-center md:px-10 md:pb-5 md:pt-4 [@media(orientation:landscape)_and_(max-height:600px)]:h-[92px] [@media(orientation:landscape)_and_(max-height:600px)]:px-6 [@media(orientation:landscape)_and_(max-height:600px)]:pb-2 [@media(orientation:landscape)_and_(max-height:600px)]:pt-1"}
                    >
                        <p className="font-sans text-[10px] font-medium uppercase tracking-[0.30em] text-brand-gold/90 md:text-xs [@media(orientation:landscape)_and_(max-height:600px)]:text-[8px]">
                            {getArtworkPresentation(artwork, locale).yearLabel}
                        </p>

                        <h2 className="mt-1.5 font-display text-2xl font-light leading-[1.05] tracking-[0.01em] md:text-3xl [@media(orientation:landscape)_and_(max-height:600px)]:mt-0.5 [@media(orientation:landscape)_and_(max-height:600px)]:text-lg">
                            {artwork.title}
                        </h2>

                        <div className="mt-2.5 font-sans text-[9px] uppercase tracking-[0.18em] text-white/45 md:text-[10px] [@media(orientation:landscape)_and_(max-height:600px)]:mt-0.5 [@media(orientation:landscape)_and_(max-height:600px)]:text-[7px]">
                            <span>{techniqueLabel}</span>
                            <span className="mx-3 text-brand-gold/40">·</span>
                            <span>
                                {artwork.dimensions.width} × {artwork.dimensions.height} {artwork.dimensions.unit}
                            </span>
                        </div>

                        {isGlass ? <div aria-hidden className={styles.separator} dangerouslySetInnerHTML={{ __html: glassSeparatorMarkup(frameId + "-separator") }} /> : <div aria-hidden className="mx-auto mt-3 h-px w-16 bg-gradient-to-r from-transparent via-brand-gold/45 to-transparent [@media(orientation:landscape)_and_(max-height:600px)]:mt-1" />}

                        {isGlass ? (
                            <div className={styles.descriptionSlot}>
                                <p ref={active ? descriptionRef : undefined} lang={artworkTextLocale(artwork, locale)} className={`${styles.descriptionPreview} font-sans text-sm font-light leading-6 text-white/45`} aria-hidden={frameDescriptionExpanded || undefined}>
                                    {artwork.description}
                                </p>
                                {(descriptionOverflows || frameDescriptionExpanded || (embedded && Boolean(artwork.description?.trim()))) && (
                                    <button
                                        ref={active ? descriptionButtonRef : undefined}
                                        type="button"
                                        data-lightbox-description-toggle
                                        aria-expanded={frameDescriptionExpanded}
                                        aria-controls={frameDescriptionExpanded ? `${frameId}-description` : undefined}
                                        className={`${styles.readButton} font-sans text-[9px] uppercase tracking-[0.18em] text-white/60 transition-colors hover:text-brand-gold`}
                                        onPointerDown={(event) => event.stopPropagation()}
                                        onClick={() => { dismissSwipeHint(); setDescriptionExpanded((expanded) => !expanded); }}
                                    >
                                        {t(frameDescriptionExpanded ? "readLess" : "readMore")}
                                    </button>
                                )}
                            </div>
                        ) : (<div className="mx-auto mt-3 max-w-xl [@media(orientation:landscape)_and_(max-height:600px)]:hidden">
                            {artwork.description && (
                                <p lang={artworkTextLocale(artwork, locale)} className="font-sans text-sm font-light leading-6 text-white/45">
                                    {artwork.description}
                                </p>
                            )}
                        </div>)}

                        {/* Contextual artwork actions */}
                        {showDetailsCta && (
                            <div
                                className={isGlass ? styles.actions : "mt-4 flex w-full items-center justify-center gap-4 whitespace-nowrap md:mt-5 md:gap-7 [@media(orientation:landscape)_and_(max-height:600px)]:absolute [@media(orientation:landscape)_and_(max-height:600px)]:bottom-1 [@media(orientation:landscape)_and_(max-height:600px)]:left-1/2 [@media(orientation:landscape)_and_(max-height:600px)]:mt-0 [@media(orientation:landscape)_and_(max-height:600px)]:w-auto [@media(orientation:landscape)_and_(max-height:600px)]:-translate-x-1/2 [@media(orientation:landscape)_and_(max-height:600px)]:gap-4"}
                            >
                                <Link
                                    href={detailsHref}
                                    onPointerDown={(event) =>
                                        event.stopPropagation()
                                    }
                                    className="
                                        relative
                                        font-sans
                                        text-[9px]
                                        font-medium
                                        uppercase
                                        tracking-[0.16em]
                                        text-white/55
                                        transition-colors
                                        duration-300

                                        hover:text-brand-gold

                                        focus-visible:text-brand-gold
                                        focus-visible:outline-none

                                        md:text-[10px]
                                        md:tracking-[0.22em]

                                        [@media(orientation:landscape)_and_(max-height:600px)]:text-[8px]
                                    "
                                >
                                    {detailsLabel}

                                    <span
                                        aria-hidden
                                        className="ml-1.5 inline-block"
                                    >
                                        →
                                    </span>
                                    <ArtworkLinkFeedback />
                                </Link>

                                {showAllWorksCta && (
                                    <>
                                        <span
                                            aria-hidden
                                            className="h-3 w-px bg-white/15"
                                        />

                                        <Link
                                            href="/artworks"
                                            onPointerDown={(event) =>
                                                event.stopPropagation()
                                            }
                                            className="
                                                font-sans
                                                text-[9px]
                                                font-medium
                                                uppercase
                                                tracking-[0.16em]
                                                text-white/55
                                                transition-colors
                                                duration-300

                                                hover:text-brand-gold

                                                focus-visible:text-brand-gold
                                                focus-visible:outline-none

                                                md:text-[10px]
                                                md:tracking-[0.22em]

                                                [@media(orientation:landscape)_and_(max-height:600px)]:text-[8px]
                                            "
                                        >
                                            {t("viewAll")}

                                            <span
                                                aria-hidden
                                                className="ml-1.5 inline-block"
                                            >
                                                →
                                            </span>
                                        </Link>
                                    </>
                                )}
                            </div>
                        )}
                    </div>
                    </div>
                    </div>
                    <ArtworkReadingPanel id={`${frameId}-description`} title={artwork.title} description={artwork.description}
                        lang={artworkTextLocale(artwork, locale)} expanded={isGlass && frameDescriptionExpanded}
                        landscape={embedded && layout === "landscape"}
                        onClose={() => { setDescriptionExpanded(false); requestAnimationFrame(() => descriptionButtonRef.current?.focus({ preventScroll: true })); }} />
                    </>}
                </Panel>
        );
    }

    const content = (
        <div
            className={isGlass ? `${styles.dialog} ${embedded ? styles.embedded : ""}` : "fixed inset-0 z-[100] overflow-hidden bg-[#030303] text-white"}
            data-lenis-prevent={isGlass || undefined}
            ref={dialogRef}
            role={embedded ? undefined : "dialog"}
            aria-modal={embedded ? undefined : true}
            data-lightbox-current={artwork.id}
            data-viewer-layout={layout}
            aria-label={`Artwork viewer — ${artwork.title}`}
        >
            {/* Fullscreen atmosphere — intentionally subtle */}
            <div
                aria-hidden
                className="pointer-events-none absolute inset-0 overflow-hidden"
            >
                <div className="artwork-lightbox-aura absolute left-1/2 top-[43%] h-[58vh] w-[78vw] max-w-[900px] -translate-x-1/2 -translate-y-1/2 rounded-[50%] bg-[radial-gradient(ellipse_at_center,rgba(190,145,72,0.18)_0%,rgba(125,91,52,0.10)_34%,rgba(71,55,39,0.04)_54%,transparent_74%)] blur-[42px]" />
                <div className="artwork-lightbox-smoke-a absolute left-[-16%] top-[29%] h-[120px] w-[88%] rotate-[-4deg] rounded-[50%] bg-[linear-gradient(100deg,transparent_0%,rgba(117,157,166,0.025)_20%,rgba(220,210,190,0.06)_42%,rgba(190,147,82,0.055)_60%,transparent_100%)] blur-[24px]" />
                <div className="artwork-lightbox-smoke-b absolute bottom-[22%] right-[-18%] h-[140px] w-[90%] rotate-[5deg] rounded-[50%] bg-[linear-gradient(80deg,transparent_0%,rgba(190,211,215,0.025)_20%,rgba(220,208,187,0.05)_42%,rgba(188,143,77,0.06)_62%,transparent_100%)] blur-[26px]" />
                <span className="artwork-particle artwork-particle-1" />
                <span className="artwork-particle artwork-particle-2" />
                <span className="artwork-particle artwork-particle-3" />
                <span className="artwork-particle artwork-particle-4" />
                <span className="artwork-particle artwork-particle-5" />
                <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_28%,rgba(0,0,0,0.28)_68%,rgba(0,0,0,0.80)_100%)]" />
            </div>

            {/* Counter — inset from viewport edges */}
            <div className={isGlass ? `${styles.counter} fixed left-7 top-7 z-[140] font-sans text-[10px] uppercase tracking-[0.22em] text-white/35 md:left-10 md:top-9` : "fixed left-7 top-7 z-[140] font-sans text-[10px] uppercase tracking-[0.22em] text-white/35 md:left-10 md:top-9"}>
                {String(currentIndex + 1).padStart(2, "0")}
                {" / "}
                {String(total).padStart(2, "0")}
            </div>

            {/* Close */}
            {!embedded && <button
                ref={closeButtonRef}
                type="button"
                onClick={onClose}
                onPointerDown={(event) => event.stopPropagation()}
                aria-label={t("closeViewer")}
                className={isGlass ? `${styles.closeControl} fixed right-4 top-4 z-[150] flex h-11 w-11 items-center justify-center rounded-full border border-transparent font-sans text-[32px] font-light leading-none text-white/75 transition-all duration-300 hover:border-brand-gold/35 hover:bg-brand-gold/[0.06] hover:text-brand-gold focus-visible:border-brand-gold/35 focus-visible:bg-brand-gold/[0.06] focus-visible:text-brand-gold focus-visible:outline-none md:right-8 md:top-6` : "fixed right-4 top-4 z-[150] flex h-11 w-11 items-center justify-center rounded-full border border-transparent font-sans text-[32px] font-light leading-none text-white/75 transition-all duration-300 hover:border-brand-gold/35 hover:bg-brand-gold/[0.06] hover:text-brand-gold focus-visible:border-brand-gold/35 focus-visible:bg-brand-gold/[0.06] focus-visible:text-brand-gold focus-visible:outline-none md:right-8 md:top-6"}
            >
                ×
            </button>}

            {/* Fixed artwork navigation — visible on mobile too */}
            {total > 1 && (
                <>
                    <button
                        type="button"
                        onClick={goPrevious}
                        data-artwork-arrival-navigation
                        onPointerDown={(event) => event.stopPropagation()}
                        aria-label={t("previousArtwork")}
                        className="fixed left-1 top-[42%] z-[145] flex h-12 w-12 -translate-y-1/2 items-center justify-center font-display text-4xl font-light text-white/45 transition-all duration-300 hover:scale-110 hover:text-brand-gold md:left-5 md:top-1/2 md:h-14 md:w-14 lg:left-10"
                    >
                        ‹
                    </button>
                    <button
                        type="button"
                        onClick={goNext}
                        data-artwork-arrival-navigation
                        onPointerDown={(event) => event.stopPropagation()}
                        aria-label={t("nextArtwork")}
                        className="fixed right-1 top-[42%] z-[145] flex h-12 w-12 -translate-y-1/2 items-center justify-center font-display text-4xl font-light text-white/45 transition-all duration-300 hover:scale-110 hover:text-brand-gold md:right-5 md:top-1/2 md:h-14 md:w-14 lg:right-10"
                    >
                        ›
                    </button>
                </>
            )}

            {/* Viewer */}
            <div
                ref={viewportRef}
                className={isGlass ? styles.viewer : `${hasHighlights ? styles.standardViewer : ""} relative z-20 flex h-full w-full touch-none items-center justify-center overflow-hidden px-3 py-3 md:px-20 md:py-8 [@media(orientation:landscape)_and_(max-height:600px)]:px-3 [@media(orientation:landscape)_and_(max-height:600px)]:py-2`}
                data-lenis-prevent={nativeScroll || undefined}
                data-lightbox-scroll-viewport={nativeScroll || undefined}
                onPointerDown={handlePointerDown}
                onPointerMove={handlePointerMove}
                onPointerUp={handlePointerUp}
                onPointerCancel={handlePointerCancel}
                onClick={handleBackdropClick}
            >
                {embedded && isGlass ? <div className={styles.standardTrack} data-standard-track>
                    {(total > 1 ? [-1, 0, 1] as const : [0] as const).map(offset => {
                        const index = (currentIndex + offset + total) % total;
                        const slot = offset === -1 ? "previous" : offset === 1 ? "next" : "current";
                        return <div key={slot} className={styles.standardScene} data-standard-scene={slot}
                            inert={offset !== 0} aria-hidden={offset !== 0 || undefined}
                            style={{ transform: `translateX(calc(${offset} * var(--artwork-kinetic-step, 100%)))` }}>
                            {renderPanel(artworks[index], index, slot)}
                        </div>;
                    })}
                </div> : renderPanel(artwork, currentIndex)}
                {embedded && layout === "landscape" && <div className={styles.externalDots}>{positionDots}</div>}
            </div>

            <style>{`
                @keyframes glassReflection {
                    0% { transform: translate3d(-30%, 0, 0) rotate(14deg); opacity: 0; }
                    20% { opacity: 0.42; }
                    70% { opacity: 0.22; }
                    100% { transform: translate3d(520%, 0, 0) rotate(14deg); opacity: 0; }
                }

                .artwork-glass-reflection {
                    animation: glassReflection 16s cubic-bezier(0.4, 0, 0.2, 1) infinite;
                }

                @keyframes artworkAura {
                    0% { transform: translate(-50%, -50%) scale(0.97); opacity: 0.52; }
                    50% { transform: translate(-48%, -52%) scale(1.035); opacity: 0.76; }
                    100% { transform: translate(-52%, -49%) scale(1); opacity: 0.58; }
                }

                @keyframes smokeA {
                    0% { transform: translate3d(-4%, 0, 0) rotate(-7deg) scaleX(0.96); }
                    50% { transform: translate3d(7%, -7%, 0) rotate(-3deg) scaleX(1.04); }
                    100% { transform: translate3d(14%, 3%, 0) rotate(-8deg) scaleX(1); }
                }

                @keyframes smokeB {
                    0% { transform: translate3d(5%, 2%, 0) rotate(6deg) scaleX(1); }
                    50% { transform: translate3d(-6%, -7%, 0) rotate(3deg) scaleX(1.05); }
                    100% { transform: translate3d(-13%, 2%, 0) rotate(8deg) scaleX(0.97); }
                }

                @keyframes particleFloat {
                    0% { transform: translate3d(0, 0, 0) scale(0.8); opacity: 0; }
                    25% { opacity: 0.32; }
                    75% { opacity: 0.14; }
                    100% { transform: translate3d(18px, -70px, 0) scale(1.15); opacity: 0; }
                }

                .artwork-lightbox-aura { animation: artworkAura 18s ease-in-out infinite alternate; }
                .artwork-lightbox-smoke-a { animation: smokeA 24s ease-in-out infinite alternate; }
                .artwork-lightbox-smoke-b { animation: smokeB 29s ease-in-out infinite alternate; }

                .artwork-particle {
                    position: absolute;
                    width: 3px;
                    height: 3px;
                    border-radius: 9999px;
                    background: rgba(203, 158, 83, 0.68);
                    box-shadow: 0 0 12px rgba(203, 158, 83, 0.32);
                    opacity: 0;
                    animation: particleFloat 14s ease-in-out infinite;
                }

                .artwork-particle-1 { left: 13%; top: 63%; animation-delay: 0s; }
                .artwork-particle-2 { left: 28%; top: 35%; animation-delay: 3s; }
                .artwork-particle-3 { right: 19%; top: 58%; animation-delay: 6s; }
                .artwork-particle-4 { right: 31%; top: 27%; animation-delay: 9s; }
                .artwork-particle-5 { left: 53%; top: 78%; animation-delay: 4.5s; }

                @media (prefers-reduced-motion: reduce) {
                    .artwork-lightbox-aura,
                    .artwork-lightbox-smoke-a,
                    .artwork-lightbox-smoke-b,
                    .artwork-particle,
                    .artwork-glass-reflection {
                        animation: none;
                    }
                }
            `}</style>
        </div>
    );
    return embedded ? content : createPortal(content, document.body);
}
