import { Container } from "@/shared/layout";
import { LinkButton } from "@/shared/ui/button";
import { NewsletterForm } from "@/domains/newsletter";
import InvitationMotion from "./InvitationMotion";
import { useTranslations } from "next-intl";

import { Suspense } from "react";

export default function Invitation() {
  const t = useTranslations("Home");
  return (
    <section
      id="invitation"
      data-invitation
      className="
        relative
        overflow-hidden
        bg-background-alternate
        py-[var(--section-space-generous)]
        text-white
      "
    >
      <InvitationMotion />
      <Container >
        <div
          className="
            mx-auto
            flex
            w-full
            max-w-4xl
            flex-col
            items-center
            text-center
          "
        >
          {/* Closing statement */}
          <p
            data-invitation-brand
            className="
              font-sans
              text-xs
              font-medium
              uppercase
              tracking-[0.35em]
              text-brand-gold
            "
          >
            Del Carmen
          </p>

          <h2
            data-invitation-statement
            className="
              mt-8
              font-display
              text-4xl
              font-light
              leading-[1.02]
              tracking-[0.01em]
              text-white
              md:text-6xl
              lg:text-7xl
            "
          >
            {t("taglineFirst")}
            <br />
            {t("taglineSecond")}
          </h2>

          <p
            id="newsletter"
            data-invitation-journey
            className="
              mt-6
              font-display
              text-2xl
              font-light
              italic
              leading-[1.2]
              tracking-[0.01em]
              text-white/65
              md:text-3xl
            "
          >
            {t("invitationJourneyFirst")}
            <br />
            {t("invitationJourneySecond")}
          </p>

          {/* Newsletter */}
          <div
            data-invitation-newsletter
            className="mt-16 max-w-2xl md:mt-20">
            <p
              className="
                font-sans
                text-xs
                font-medium
                uppercase
                tracking-[0.30em]
                text-white/45
              "
            >
              {t("newsletterLabel")}
            </p>

            <p
              className="
                mt-6
                font-sans
                text-base
                font-light
                leading-[1.8]
                tracking-[0.01em]
                text-white/55
                md:text-lg
              "
            >
              {t("newsletterDescription")}
            </p>

            <Suspense fallback={null}>
              <NewsletterForm />
            </Suspense>
          </div>

          {/* Actions */}
          <div
            data-invitation-actions
            className="
              mt-10
              flex
              items-center
              justify-center
              gap-10
            "
          >

            <LinkButton
              href="/contact"
              variant="goldUnderline"
              className="
                font-sans
                text-xs
                font-medium
                tracking-[0.28em]
              "
            >
              {t("contact")}
            </LinkButton>
          </div>
        </div>
      </Container>
    </section>
  );
}
