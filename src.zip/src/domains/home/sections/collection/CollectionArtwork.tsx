"use client";

import { useRef, useState } from "react";
import Image from "next/image";
import gsap from "gsap";
import { useLocale, useTranslations } from "next-intl";
import { formatArtworkTechnique, localizeArtwork } from "@/i18n/artworkCopy";

import type { Artwork } from "@/domains/artworks";
import ArtworkBadges from "@/shared/ui/artwork/ArtworkBadges";
import ArtworkComingSoon from "@/shared/ui/artwork/ArtworkComingSoon";
import ArtworkLoading from "@/shared/ui/artwork/ArtworkLoading";
import feedbackStyles from "@/shared/ui/artwork/ArtworkNavigationFeedback.module.css";
import { getArtworkPresentation } from "@/domains/artworks/presentation/getArtworkPresentation";
import { getArtworkThumbnailSizes } from "@/shared/ui/artwork/artworkThumbnailSizes";

import CollectionArtworkFrame from "./CollectionArtworkFrame";
import styles from "./CollectionArtwork.module.css";

type CollectionImageVariant =
  | "collection"
  | "thumbnail";

interface CollectionArtworkProps {
  artwork: Artwork;
  onOpen?: () => void;
  loading?: boolean;

  imageVariant?: CollectionImageVariant;
  presentation?: "default" | "series" | "archive";
}

export default function CollectionArtwork({
  artwork: sourceArtwork,
  onOpen,
  loading = false,
  imageVariant = "thumbnail",
  presentation = "default",
}: CollectionArtworkProps) {
  const locale = useLocale();
  const t = useTranslations("Artwork");
  const artwork = localizeArtwork(sourceArtwork, locale);
  const cardRef = useRef<HTMLDivElement>(null);
  const [cardActive, setCardActive] = useState(false);
  const initialRef = useRef<HTMLDivElement>(null);
  const detailsRef = useRef<HTMLDivElement>(null);
  const detailsTitleRef = useRef<HTMLHeadingElement>(null);
  const metaRef = useRef<HTMLDivElement>(null);
  const footerRef = useRef<HTMLDivElement>(null);

  const displayImage =
    imageVariant === "collection"
      ? artwork.images.collection ??
      artwork.images.primary
      : artwork.images.thumbnail ??
      artwork.images.primary;
  const imageSizes = getArtworkThumbnailSizes(presentation, displayImage);

  const techniqueLabel = locale === "es" ? formatArtworkTechnique(artwork, locale) : `${artwork.medium} on ${artwork.support}`;
  const presentationInfo = getArtworkPresentation(artwork, locale);

  const animateIn = () => {
    if (
      !initialRef.current ||
      !detailsRef.current ||
      !detailsTitleRef.current ||
      !metaRef.current ||
      !footerRef.current
    ) {
      return;
    }

    gsap.killTweensOf([
      initialRef.current,
      detailsRef.current,
      detailsTitleRef.current,
      metaRef.current,
      footerRef.current,
    ]);

    const timeline = gsap.timeline();

    timeline.to(initialRef.current, {
      opacity: 0,
      duration: 0.25,
      ease: "power2.out",
    });

    timeline.fromTo(
      detailsRef.current,
      {
        opacity: 0,
      },
      {
        opacity: 1,
        duration: 0.3,
        ease: "power2.out",
      },
      "-=0.05",
    );

    timeline.fromTo(
      detailsTitleRef.current,
      {
        y: 18,
        opacity: 0,
      },
      {
        y: 0,
        opacity: 1,
        duration: 0.45,
        ease: "power3.out",
      },
      "-=0.15",
    );

    timeline.fromTo(
      metaRef.current,
      {
        y: 10,
        opacity: 0,
      },
      {
        y: 0,
        opacity: 1,
        duration: 0.35,
        ease: "power2.out",
      },
      "-=0.2",
    );

    timeline.fromTo(
      footerRef.current,
      {
        y: 8,
        opacity: 0,
      },
      {
        y: 0,
        opacity: 1,
        duration: 0.35,
        ease: "power2.out",
      },
      "-=0.15",
    );
  };

  const animateOut = () => {
    if (
      !initialRef.current ||
      !detailsRef.current ||
      !detailsTitleRef.current ||
      !metaRef.current ||
      !footerRef.current
    ) {
      return;
    }

    gsap.killTweensOf([
      initialRef.current,
      detailsRef.current,
      detailsTitleRef.current,
      metaRef.current,
      footerRef.current,
    ]);

    const timeline = gsap.timeline();

    timeline.to(
      [
        detailsTitleRef.current,
        metaRef.current,
        footerRef.current,
      ],
      {
        y: 8,
        opacity: 0,
        duration: 0.2,
        ease: "power2.in",
        stagger: 0.03,
      },
    );

    timeline.to(
      detailsRef.current,
      {
        opacity: 0,
        duration: 0.2,
        ease: "power2.in",
      },
      "-=0.05",
    );

    timeline.to(
      initialRef.current,
      {
        opacity: 1,
        duration: 0.35,
        ease: "power2.out",
      },
      "-=0.05",
    );
  };

  return (
    <article
      lang={locale}
      ref={cardRef}
      data-active={cardActive || undefined}
      data-creation-status={artwork.creationStatus}
      className={`group relative w-full ${presentation === "series"
        ? "max-w-[260px]"
        : presentation === "archive" ? styles.archive : "max-w-[200px]"
        }`}
      onMouseEnter={() => { setCardActive(true); animateIn(); }}
      onMouseLeave={() => { setCardActive(false); animateOut(); }}
      onFocusCapture={() => { setCardActive(true); animateIn(); }}
      onBlurCapture={(event) => {
        if (!event.currentTarget.contains(event.relatedTarget as Node | null)) { setCardActive(false); animateOut(); }
      }}
    >
      <button
        type="button"
        onClick={() => { if (!loading) onOpen?.(); }}
        disabled={loading}
        aria-busy={loading}
        className={`relative block w-full text-left ${feedbackStyles.pressable}`}
        aria-label={`${t("viewNamed", { title: artwork.title })}${presentationInfo.badges.length ? ` — ${presentationInfo.badges.map((badge) => badge.label).join(", ")}` : ""}`}
      >
        <CollectionArtworkFrame>
          <div className="relative aspect-[4/5] overflow-hidden bg-black">
            {artwork.creationStatus !== "completed" ? <ArtworkComingSoon artwork={artwork} variant="thumbnail" imageSizes={imageSizes} /> : <Image
              src={displayImage.src}
              alt={displayImage.alt}
              width={displayImage.width ?? artwork.images.primary.width ?? 1200}
              height={displayImage.height ?? artwork.images.primary.height ?? 1200}
              sizes={imageSizes}
              quality={75}
              loading="lazy"
              decoding="async"
              className="
                h-full
                w-full
                object-cover
                transition-transform
                duration-1000
                ease-out
                group-hover:scale-[1.035]
              "
            />}

            {artwork.creationStatus === "completed" && <div
              className="
                absolute
                inset-0
                bg-gradient-to-t
                from-black/90
                via-black/10
                to-transparent
                opacity-70
                transition-opacity
                duration-700
                group-hover:opacity-90
              "
            />}

            <div data-collection-caption className="absolute inset-x-0 bottom-0 p-4 md:p-5">
              {/* Estado inicial */}
              <div ref={initialRef} data-collection-caption-initial aria-hidden={presentation === "archive" ? cardActive : undefined}>
                <p className="mb-2 text-[9px] uppercase tracking-[0.3em] text-brand-gold">
                  {presentationInfo.yearLabel}
                </p>

                <h3 className="font-serif text-lg font-light leading-tight text-white">
                  {artwork.title}
                </h3>
              </div>

              {/* Estado revelado */}
              <div
                ref={detailsRef}
                data-collection-caption-details
                aria-hidden={presentation === "archive" ? !cardActive : undefined}
                className="
                  absolute
                  inset-x-0
                  bottom-0
                  p-4
                  opacity-0

                  md:p-5
                "
              >
                <h3
                  ref={detailsTitleRef}
                  className="font-serif text-lg font-light leading-tight text-white"
                >
                  {artwork.title}
                </h3>

                <div
                  ref={metaRef}
                  data-collection-meta
                  className="
                    mt-3
                    space-y-1
                    text-[8px]
                    uppercase
                    tracking-[0.2em]
                    text-white/55
                  "
                >
                  <p>{techniqueLabel}</p>

                  <p>
                    {artwork.dimensions.width} ×{" "}
                    {artwork.dimensions.height}{" "}
                    {artwork.dimensions.unit}
                  </p>
                </div>

                <div
                  ref={footerRef}
                  data-collection-footer
                  className="mt-4 flex items-center justify-between"
                >
                  <span className="text-[9px] uppercase tracking-[0.3em] text-brand-gold">
                    {presentation === "archive" ? artwork.year : presentationInfo.yearLabel}
                  </span>

                  <span data-collection-discover className="text-[9px] uppercase tracking-[0.25em] text-brand-gold">
                    {presentation === "archive" ? <>{t("discover").replace(/\s*→$/, "")}<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M4 12h16m-6-6 6 6-6 6" /></svg></> : t("discover")}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </CollectionArtworkFrame>
        <ArtworkBadges key={artwork.id} artwork={artwork} variant="thumbnail" passive expanded={cardActive} className={presentation === "archive" ? styles.badges : undefined} />
      </button>
      {loading && <span className={feedbackStyles.overlay}><ArtworkLoading label={t("opening")} /></span>}
    </article>
  );
}
