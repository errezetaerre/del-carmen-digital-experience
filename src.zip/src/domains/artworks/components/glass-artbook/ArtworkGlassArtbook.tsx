"use client";

import { useLocale, useTranslations } from "next-intl";
import { localizeHref } from "@/i18n/config";
import { localizeArtwork } from "@/i18n/artworkCopy";
import ArtworkExperienceToolbar from "@/shared/ui/artwork/ArtworkExperienceToolbar";
import { setArtworkExperiencePreference } from "@/shared/ui/artwork/artworkExperiencePreference";

import { useCallback, useEffect, useId, useLayoutEffect, useMemo, useRef, useState } from "react";
import useClientReady from "@/shared/hooks/useClientReady";
import { createPortal } from "react-dom";
import Link from "@/i18n/navigation";
import { usePathname, useRouter } from "@/i18n/navigation";
import gsap from "gsap";
import useArtworkGestureBoundary from "@/shared/ui/artwork/useArtworkGestureBoundary";
import type { Artwork } from "@/domains/artworks";
import { getArtworkPresentation } from "../../presentation/getArtworkPresentation";
import { artworkExperienceHref } from "../../presentation/artworkExperience";
import ArtworkDetailViewer from "../ArtworkDetailViewer";
import ArtworkBadges from "@/shared/ui/artwork/ArtworkBadges";
import ArtworkLoading from "@/shared/ui/artwork/ArtworkLoading";
import { bindArtworkReadingPanels } from "@/shared/ui/artwork/bindArtworkReadingPanels";
import { artworkPreviewMarkup } from "@/shared/ui/artwork/artworkPreviewMarkup";
import { createGlassArtbook, GLASS_BOOK_QUERY } from "./runtime.mjs";
import type { ArtworkGlassArtbookProps, GlassArtbookController, GlassArtbookLoadState } from "./types";
import styles from "./ArtworkGlassArtbook.module.css";

export default function ArtworkGlassArtbook({
    artworks: sourceArtworks, initialArtworkId, navigationQuery, backHref, backLabel, host, onExit,
}: ArtworkGlassArtbookProps) {
    const embedded = Boolean(host);
    const hostedArtworkId = host?.artworkId;
    const latestHost = useRef(host);
    useLayoutEffect(() => { latestHost.current = host; });
    const locale = useLocale();
    const t = useTranslations("Glass");
    const artworkT = useTranslations("Artwork");
    const artworks = useMemo(() => sourceArtworks.map((artwork) => localizeArtwork(artwork, locale)), [sourceArtworks, locale]);
    const pathname = usePathname();
    const router = useRouter();
    const id = useId();
    const instanceId = `glass${id.replace(/[^a-zA-Z0-9_-]/g, "")}`;
    const hostRef = useRef<HTMLDivElement>(null);
    const experienceRef = useRef<HTMLElement>(null);
    const controllerRef = useRef<GlassArtbookController | null>(null);
    const initialIdRef = useRef(initialArtworkId);
    const onNavigateRef = useRef<(artwork: Artwork) => void>(() => {});
    const dataKey = useMemo(() => JSON.stringify(artworks), [artworks]);
    const clientReady = useClientReady();
    const portalHost = clientReady ? document.body : null;
    const [experienceHost, setExperienceHost] = useState<HTMLElement | null>(null);
    useArtworkGestureBoundary(experienceRef, Boolean(experienceHost));
    const captureExperience = useCallback((host: HTMLElement | null) => {
        experienceRef.current = host;
        setExperienceHost(host);
    }, []);
    const [bookEligible, setBookEligible] = useState<boolean | null>(embedded ? true : null);
    const [actionsHost, setActionsHost] = useState<HTMLElement | null>(null);
    const [highlightsHosts, setHighlightsHosts] = useState<HTMLElement[]>([]);
    const [positionHost, setPositionHost] = useState<HTMLElement | null>(null);
    const positionRail = useRef<HTMLDivElement>(null);
    const routedArtwork = useMemo(() => {
        if (hostedArtworkId) return artworks.find(item => item.id === hostedArtworkId) ?? null;
        if (!pathname?.startsWith("/artworks/")) return null;
        try {
            const slug = decodeURIComponent(pathname.slice("/artworks/".length).replace(/\/$/, ""));
            return artworks.find((item) => item.slug === slug) ?? null;
        } catch { return null; }
    }, [pathname, artworks, hostedArtworkId]);
    const selectedArtwork = routedArtwork ?? artworks.find((item) => item.id === initialArtworkId) ?? artworks[0] ?? null;
    const [highlightArtworks, setHighlightArtworks] = useState<[Artwork | null, Artwork | null]>([null, null]);
    const [loadState, setLoadState] = useState<GlassArtbookLoadState>({ status: "loading", artworkId: initialArtworkId, kind: "entrance" });
    const standardHref = selectedArtwork
        ? artworkExperienceHref(selectedArtwork.slug, navigationQuery, "standard")
        : "/artworks";

    const exit = useCallback(() => {
        if (latestHost.current) { latestHost.current.onStandardView(); return; }
        setArtworkExperiencePreference("standard");
        if (onExit) onExit(); else router.replace(standardHref, { scroll: false });
    }, [onExit, router, standardHref]);

    useEffect(() => {
        if (embedded) return;
        const viewport = window.matchMedia(GLASS_BOOK_QUERY);
        let pendingDialog: MutationObserver | null = null;
        const update = () => {
            if (!viewport.matches && document.querySelector('[role="dialog"][aria-modal="true"]')) {
                if (!pendingDialog) {
                    pendingDialog = new MutationObserver(update);
                    pendingDialog.observe(document.body, { childList: true, subtree: true });
                }
                return;
            }
            pendingDialog?.disconnect();
            pendingDialog = null;
            setBookEligible(viewport.matches);
        };
        update();
        viewport.addEventListener("change", update);
        return () => {
            viewport.removeEventListener("change", update);
            pendingDialog?.disconnect();
        };
    }, [embedded]);

    useEffect(() => {
        if (!embedded && bookEligible === false) router.replace(standardHref, { scroll: false });
    }, [bookEligible, embedded, router, standardHref]);

    useEffect(() => {
        if (embedded || !portalHost || !bookEligible) return;
        const previousOverflow = document.documentElement.style.overflow;
        document.documentElement.style.overflow = "hidden";
        const previousFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
        const siblings = Array.from(document.body.children)
            .filter((node): node is HTMLElement => node instanceof HTMLElement && node !== experienceRef.current && node.tagName !== "SCRIPT")
            .map((node) => ({ node, inert: node.inert }));
        siblings.forEach(({ node }) => { node.inert = true; });
        experienceRef.current?.querySelector<HTMLElement>("[data-glass-exit]")?.focus({ preventScroll: true });
        return () => {
            document.documentElement.style.overflow = previousOverflow;
            siblings.forEach(({ node, inert }) => { node.inert = inert; });
            if (previousFocus?.isConnected) previousFocus.focus({ preventScroll: true });
        };
    }, [portalHost, bookEligible, embedded]);

    useEffect(() => {
        onNavigateRef.current = (artwork) => {
            if (latestHost.current) { latestHost.current.onNavigate(artwork); return; }
            const query = new URLSearchParams(navigationQuery);
            query.set("experience", "glass");
            window.history.pushState(null, "", localizeHref(`/artworks/${artwork.slug}?${query.toString()}`, locale));
        };
    }, [navigationQuery, locale]);

    useLayoutEffect(() => {
        const host = hostRef.current;
        const items: Artwork[] = JSON.parse(dataKey);
        if (!portalHost || !bookEligible || !host || !items.length) return;
        // Establish the gate before a new native tree can paint, including
        // catalogue/filter rebuilds after this component was already ready.
        setLoadState({ status: "loading", artworkId: initialIdRef.current, kind: "entrance" });
        const controller = createGlassArtbook(host, {
            artworks: items,
            initialArtworkId: initialIdRef.current,
            instanceId,
            locale,
            motion: gsap,
            getPresentation: (artwork) => getArtworkPresentation(artwork, locale),
            renderPreview: (artwork) => artworkPreviewMarkup(artwork, locale),
            renderInformation: embedded ? (artwork, id) => latestHost.current!.renderInformation(artwork, id) : undefined,
            onHighlightArtwork: (slot, artwork) => setHighlightArtworks((previous) => {
                const next: [Artwork | null, Artwork | null] = [...previous];
                next[slot] = artwork;
                return next;
            }),
            onNavigate: (artwork) => onNavigateRef.current(artwork),
            onLoadStateChange: state => { setLoadState(state); latestHost.current?.onLoadStateChange?.(state); },
        });
        controllerRef.current = controller;
        setActionsHost(host.querySelector<HTMLElement>("[data-glass-artwork-actions]"));
        setHighlightsHosts(Array.from(host.querySelectorAll<HTMLElement>("[data-glass-artwork-highlights]")));
        setPositionHost(embedded ? host.querySelector<HTMLElement>(".control-center") : null);
        const unbindReading = embedded ? bindArtworkReadingPanels(host) : () => {};
        return () => { unbindReading(); controller.dispose(); controllerRef.current = null; setActionsHost(null); setHighlightsHosts([]); setPositionHost(null); setHighlightArtworks([null, null]); };
    }, [dataKey, instanceId, portalHost, bookEligible, locale, embedded]);

    useLayoutEffect(() => {
        const rail = positionRail.current;
        const active = rail?.querySelector<HTMLButtonElement>('[aria-current="true"]');
        if (!rail || !active) return;
        // Scroll this rail only. scrollIntoView could shift the whole book.
        rail.scrollLeft = Math.max(0, active.offsetLeft + active.offsetWidth / 2 - rail.clientWidth / 2);
    }, [selectedArtwork?.id, positionHost]);

    useEffect(() => {
        const item = routedArtwork;
        if (!item) return;
        initialIdRef.current = item.id;
        controllerRef.current?.select(item.id);
    }, [routedArtwork]);

    useEffect(() => {
        if (embedded || !portalHost || !bookEligible) return;
        const onKeyDown = (event: KeyboardEvent) => {
            if (event.key !== "Escape" || document.querySelector('[role="dialog"][aria-modal="true"]')) return;
            event.preventDefault();
            exit();
        };
        document.addEventListener("keydown", onKeyDown);
        return () => { document.removeEventListener("keydown", onKeyDown); };
    }, [portalHost, bookEligible, embedded, exit]);

    if (!selectedArtwork) return null;
    if (!portalHost || !bookEligible) {
        return (
            <main className="min-h-screen bg-surface-deep text-white">
                <h1 className="sr-only">{selectedArtwork.title}</h1>
                {bookEligible !== false && <div className="grid min-h-screen place-items-center px-6 py-20"><ArtworkLoading label={t("opening")} /></div>}
                {bookEligible === false && <Link href={standardHref} className="block px-6 py-12 font-sans text-sm text-white/60">{t("standard")}</Link>}
                <noscript><a href={localizeHref(standardHref, locale)}>{t("openStandard", { title: selectedArtwork.title })}</a></noscript>
            </main>
        );
    }

    const content = (
        <main ref={captureExperience} className={`${styles.experience} ${embedded ? styles.embedded : ""} bg-surface-deep text-white`} data-lenis-prevent aria-label={t("immersive")}>
            {!embedded && <ArtworkExperienceToolbar backHref={backHref} backLabel={backLabel} onExit={exit} className={styles.toolbar} />}
            <h1 className="sr-only">{selectedArtwork.title}</h1>
            <div className={styles.bookViewport} data-lenis-prevent aria-busy={loadState.status === "loading"}>
                <div ref={hostRef} className={`${styles.root} font-sans`} inert={loadState.status !== "ready" && !(loadState.status === "loading" && loadState.kind === "turn")} aria-label={t("viewer")} />
            </div>
            {loadState.status !== "ready" && <div className={`${styles.loadingPanel} ${loadState.kind === "turn" ? styles.turnLoading : ""}`}>
                {loadState.status === "loading" ? <ArtworkLoading label={t(loadState.kind === "turn" ? "loadingArtwork" : "preparing")} /> : <div className={styles.loadError}>
                    <p role="alert" className="font-sans text-sm text-white/70">{t("error")}</p>
                    <button type="button" onClick={() => controllerRef.current?.retry()} className="font-sans text-[10px] uppercase tracking-[0.2em] text-brand-gold transition-colors hover:text-white focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-brand-gold/60">{t("retry")}</button>
                    <>{host ? <button type="button" onClick={host.onStandardView} className="font-sans text-[10px] uppercase tracking-[0.2em] text-white/60 hover:text-brand-gold">{t("standard")}</button> : <button type="button" onClick={exit} className="font-sans text-[10px] uppercase tracking-[0.2em] text-white/60 transition-colors hover:text-brand-gold">{t("standard")}</button>}</>
                </div>}
            </div>}
            {actionsHost && experienceHost && createPortal(
                <ArtworkDetailViewer artwork={selectedArtwork} triggerOnly gestureRoot={hostRef} portalTarget={experienceHost} />,
                actionsHost,
            )}
            {positionHost && createPortal(
                <div ref={positionRail} className={styles.positionDots} data-glass-position-dots role="group" aria-label={t("viewer")}>
                    {artworks.map(artwork => <button key={artwork.id} type="button"
                        aria-label={artworkT("viewNamed", { title: artwork.title })}
                        aria-current={artwork.id === selectedArtwork.id ? "true" : undefined}
                        disabled={loadState.status !== "ready"}
                        onClick={() => {
                            if (artwork.id === selectedArtwork.id) return;
                            controllerRef.current?.select(artwork.id);
                            onNavigateRef.current(artwork);
                        }} />)}
                </div>, positionHost,
            )}
            {highlightsHosts.map((host, slot) => {
                const artwork = highlightArtworks[slot];
                return artwork ? createPortal(
                    <div key={artwork.id} data-glass-highlight-artwork={artwork.id}>
                        <ArtworkBadges artwork={artwork} />
                    </div>,
                    host,
                    `highlights-${slot}`,
                ) : null;
            })}
        </main>
    );
    return embedded ? content : createPortal(content, portalHost);
}
