import type { Artwork } from "../model";

export const artworks: Artwork[] = [
  {
    id: "captura_de_jesucristo",

    slug: "captura-de-jesucristo",

    title: "Captura de Jesucristo",

    year: 2025,

    creationStatus: "completed",

    authorship: "master-copy",

    context: "academic-study",

    medium: "oil",

    support: "canvas",

    categories: [
      "figurative",
      "spiritual",
      "study"
    ],

    dimensions: {
      width: 100,
      height: 80,
      unit: "cm",
    },

    images: {
      primary: {
        src: "/artworks/captura_de_jesucristo.webp",
        alt: "Captura de Jesucristo, master copy by Rolando Del Carmen",
        width: 2723,
        height: 2036
      },
    },

    quote:
      "Capture of Christ is the start of everything.",

    description:
      "When the world is lost, Jesus is the only hope.",

    availability: "available",

    price: {
      amount: 2500,
      currency: "USD",
    },
  },

  {
    id: "epifania_nupcial",

    slug: "epifania-nupcial",

    title: "Epifanía Nupcial",

    year: 2022,

    creationStatus: "completed",

    authorship: "original",

    context: "independent",

    medium: "oil",

    support: "canvas",

    categories: [
      "portrait",
      "spiritual",
      "symbolic",
    ],
    seriesId: "epifanias",

    dimensions: {
      width: 113,
      height: 95,
      unit: "cm",
    },

    images: {
      primary: {
        src: "/artworks/epifania_nupcial.webp",
        alt: "Epifanía Nupcial by Rolando Del Carmen",
        width: 1376,
        height: 768
      },

      heroLandscape: {
        src: "/images/hero/epifania_nupcial_hero_landscape.webp",
        alt: "Epifanía Nupcial, landscape composition for the Del Carmen Hero",
      },

      heroPortrait: {
        src: "/images/hero/epifania_nupcial_hero_portrait.webp",
        alt: "Epifanía Nupcial, portrait composition for the Del Carmen Hero",
      },
    },

    quote:
      "She wears no veil, only silence.",

    description:
      "A moment suspended between memory, devotion and becoming.",

    availability: "available",

    price: {
      amount: 6000,
      currency: "USD",
    },
  },

  {
    id: "el_misionero",

    slug: "el-misionero",

    title: "El Misionero",

    year: 2024,

    creationStatus: "completed",

    authorship: "original",

    context: "independent",

    medium: "oil",

    support: "canvas",

    categories: [
      "portrait",
      "study",
      "spiritual",
      "figurative",
      "symbolic",
    ],

    dimensions: {
      width: 60,
      height: 70,
      unit: "cm",
    },

    images: {
      primary: {
        src: "/artworks/el_misionero.webp",
        alt: "El Misionero by Rolando Del Carmen",
        width: 832,
        height: 1279,
      },
    },

    quote:
      "She wears no mission, only silence.",

    description:
      "A quiet meditation on inner light, compassion, freedom and the mission within.",

    availability: "available",

    price: {
      amount: 6000,
      currency: "USD",
    },
  },

  {
    id: "perro_de_dani",

    slug: "perro-de-dani",

    title: "Perro de Dani",

    year: 2019,

    creationStatus: "completed",

    authorship: "original",

    context: "independent",

    medium: "oil",

    support: "canvas",

    categories: [
      "portrait",
      "animal-lover",
    ],

    dimensions: {
      width: 50,
      height: 40,
      unit: "cm",
    },

    images: {
      primary: {
        src: "/artworks/perro_de_dani.webp",
        alt: "Portrait of Dani's dog by Rolando Del Carmen",
        width: 720,
        height: 728,
      },
    },

    quote:
      "Love is found in the eyes of a dog.",

    description:
      "Copy artwork created taking as reference a photo of the owner dog. As friends we agreed to share some of our paitings of each other. It was retouched by photoshop.",

    availability: "reserved",

    price: {
      amount: 1500,
      currency: "USD",
    },
  },

  {
    id: "el_carnero",

    slug: "el-carnero",

    title: "El Carnero",

    year: 2019,

    creationStatus: "completed",

    authorship: "original",

    context: "academic-study",

    medium: "charcoal",

    support: "tonal paper Strathmore",

    seriesId: "the_discipline_of_seeing",

    categories: [
      "figurative",
      "spiritual",
      "still-life",
      "cast",
    ],

    dimensions: {
      width: 45,
      height: 35,
      unit: "cm",
    },

    images: {
      primary: {
        src: "/artworks/el_carnero.webp",
        alt: "El Carnero, charcoal academic study by Rolando Del Carmen",
        width: 720,
        height: 556,
      },
    },

    quote:
      "Original cast artwork study",

    description:
      "My niece liked because it was a representation of the infedility of her boyfriend. It was created by observation. 2nd place. Best cast of the year 2019.",

    availability: "reserved",

    price: {
      amount: 600,
      currency: "USD",
    },
  },

  {
    id: "el_baul_de_los_tesoros",

    slug: "el-baul-de-los-tesoros",

    title: "El Baúl de los Tesoros",

    year: 2022,

    creationStatus: "completed",

    authorship: "original",

    context: "independent",

    medium: "oil",

    support: "canvas",

    categories: [
      "still-life",
      "spiritual",
      "academic",
      "symbolic",
      "figurative"
    ],
    seriesId: "the_inner_treasury",

    dimensions: {
      width: 90,
      height: 60,
      unit: "cm",
    },

    images: {
      primary: {
        src: "/artworks/el_baul_de_los_tesoros.webp",
        alt: "El Baúl de los Tesoros by Rolando Del Carmen",
        width: 1090,
        height: 1489,
      },
    },

    quote:
      "She wears no baúl, only silence.",

    description:
      "A symbolic journey toward the discovery of the soul and the treasures hidden within.",

    availability: "available",

    price: {
      amount: 6000,
      currency: "USD",
    },
  },

  {
    id: "buda",

    slug: "buda",

    title: "Buda",

    year: 2027,

    creationStatus: "planned",

    authorship: "original",

    context: "independent",

    medium: "oil",

    support: "canvas",

    categories: [
      "spiritual",
      "symbolic",
      "figurative",
    ],
    seriesId: "the_inner_treasury",

    dimensions: {
      width: 60,
      height: 90,
      unit: "cm",
    },

    images: {
      primary: {
        src: "/artworks/buda.webp",
        alt: "Buda, planned artwork preview by Rolando Del Carmen",
        width: 1024,
        height: 1168,
      },
    },

    quote:
      "The journey inward is the path to enlightenment.",

    description:
      "This artwork captures the serene and contemplative essence of Buddha, inviting viewers to reflect on inner peace, mindfulness, and the pursuit of enlightenment.",

    availability: "unavailable",

    price: {
      amount: 12000,
      currency: "USD",
    },
  },



  {
    id: "sendero_del_sol",

    slug: "sendero-del-sol",

    title: "Sendero del Sol",

    year: 2023,

    creationStatus: "completed",

    authorship: "original",

    context: "independent",

    medium: "oil",

    support: "canvas",

    categories: [
      "landscape",
      "spiritual",
      "symbolic",
      "figurative",
      "academic",
      "portrait"
    ],

    seriesId: "epifanias",

    dimensions: {
      width: 100,
      height: 130,
      unit: "cm",
    },

    images: {
      primary: {
        src: "/artworks/sendero_del_sol.webp",
        alt: "Sendero del Sol by Rolando Del Carmen",
        width: 2096,
        height: 2792,
      },
    },

    quote:
      "She wears no sendero, only silence.",

    description:
      "A reflection on life's path, hope, serenity and the light we leave behind.",

    availability: "available",

    price: {
      amount: 6000,
      currency: "USD",
    },
  },

  {
    id: "margarita",

    slug: "margarita",

    title: "Margarita",

    year: 2027,

    creationStatus: "planned",

    authorship: "original",

    context: "independent",

    medium: "oil",

    support: "canvas",

    categories: [
      "symbolic",
      "figurative",
      "portrait"
    ],

    seriesId: "epifanias",

    dimensions: {
      width: 130,
      height: 130,
      unit: "cm",
    },

    images: {
      primary: {
        src: "/artworks/margarita.webp",
        alt: "Margarita, planned artwork preview by Rolando Del Carmen",
        width: 1200,
        height: 992,
      },
    },

    quote:
      "A symbol of purity, innocence, and the ephemeral nature of beauty.",

    description:
      "This artwork captures the serene and contemplative essence of a young girl named Margarita, surrounded by a delicate white flower that symbolizes purity and innocence. The soft lighting and gentle expression on her face evoke a sense of tranquility and grace, inviting viewers to reflect on the simple beauty of childhood and the fleeting moments of life.",

    availability: "unavailable",

    price: {
      amount: 12000,
      currency: "USD",
    },
  },

  {
    id: "recordando_mi_puerto",

    slug: "recordando-mi-puerto",

    title: "Recordando Mi Puerto",

    year: 2027,

    creationStatus: "planned",

    authorship: "original",

    context: "independent",

    medium: "oil",

    support: "canvas",

    categories: [
      "symbolic",
      "figurative",
      "landscape"
    ],

    seriesId: "epifanias",

    dimensions: {
      width: 130,
      height: 90,
      unit: "cm",
    },

    images: {
      primary: {
        src: "/artworks/recordando_mi_puerto.webp",
        alt: "Recordando Mi Puerto, planned artwork preview by Rolando Del Carmen",
        width: 1312,
        height: 912,
      },
    },

    quote:
      "Memories of childhood near the sea under the shadow of a tree.",

    description:
      "I remember the innocence of my childhood and the beauty of the simple moments that made me who I am today. Contemplating this scene I find myself immersed in those years, in the smell of the sea and the warmth of the sun on my skin. It is a tribute to those times and to the place that saw me grow.",

    availability: "unavailable",

    price: {
      amount: 12000,
      currency: "USD",
    },
  },

  {
    id: "la_mujer_del_bosque",

    slug: "la-mujer-del-bosque",

    title: "La Mujer Del Bosque",

    year: 2027,

    creationStatus: "planned",

    authorship: "original",

    context: "independent",

    medium: "oil",

    support: "canvas",

    categories: [
      "symbolic",
      "figurative",
      "landscape",
      "portrait"
    ],

    seriesId: "epifanias",

    dimensions: {
      width: 90,
      height: 140,
      unit: "cm",
    },

    images: {
      primary: {
        src: "/artworks/la_mujer_del_bosque.webp",
        alt: "La Mujer Del Bosque, planned artwork preview by Rolando Del Carmen",
        width: 896,
        height: 1344,
      },
    },

    quote:
      "She carries the scent of leaves and the wisdom of the trees.",

    description:
      "A representation of the strength, wisdom, and beauty of nature. Her presence brings a sense of peace and tranquility to those who contemplate her.",

    availability: "unavailable",

    price: {
      amount: 6000,
      currency: "USD",
    },
  },

  {
    id: "rosa_rojita",

    slug: "rosa-rojita",

    title: "Rosa Rojita",

    year: 2024,

    creationStatus: "completed",

    authorship: "original",

    context: "independent",

    medium: "oil",

    support: "canvas",

    categories: [
      "still-life",
      "study"
    ],

    dimensions: {
      width: 30,
      height: 40,
      unit: "cm",
    },

    images: {
      primary: {
        src: "/artworks/rosa_rojita.webp",
        alt: "Rosa Rojita by Rolando Del Carmen",
        width: 2238,
        height: 2850,
      },
    },

    quote:
      "Petals full of color, a rose that blooms with intensity and passion.",

    description:
      "A red rose, with deep shadows that give it mystery and intensity.",

    availability: "available",

    price: {
      amount: 500,
      currency: "USD",
    },
  },
  {
    id: "yasemi_i",

    slug: "yasemi-i",

    title: "Yasemi I",

    year: 2025,

    creationStatus: "completed",

    authorship: "original",

    context: "independent",

    medium: "oil",

    support: "canvas",

    categories: [
      "figurative",
      "spiritual",
      "study"
    ],

    seriesId: "yasemi",

    dimensions: {
      width: 40,
      height: 30,
      unit: "cm",
    },
    images: {
      primary: {
        src: "/artworks/yasemi_I.webp",
        alt: "Yasemi I by Rolando Del Carmen",
        width: 888,
        height: 592,
      },

      thumbnail: {
        src: "/artworks/yasemi_I.webp",
        alt: "Yasemi I by Rolando Del Carmen",
        width: 444,
        height: 296,
      },

      collection: {
        src: "/artworks/yasemi_I.webp",
        alt: "Yasemi I — collection presentation",
        width: 1920,
        height: 1080,
      },
    },

    quote:
      "The seed in the depth of the ocean with no light and no air, but the seed remains.",

    description:
      "Practice with a photo of a flower in a jar with intense and vibrant colors, study soft petals and its folds.",

    availability: "available",

    price: {
      amount: 500,
      currency: "USD",
    },
  },
  {
    id: "yasemi_ii",

    slug: "yasemi-ii",

    title: "Yasemi II",

    year: 2026,

    creationStatus: "planned",

    authorship: "original",

    context: "independent",

    medium: "oil",

    support: "canvas",

    categories: [
      "figurative",
      "spiritual",
    ],

    seriesId: "yasemi",

    dimensions: {
      width: 40,
      height: 30,
      unit: "cm",
    },
    images: {
      primary: {
        src: "/artworks/yasemi_II.webp",
        alt: "Yasemi II by Rolando Del Carmen",
        width: 888,
        height: 592,
      },
    },

    quote:
      "The sea is a mirror of the soul, reflecting the depths of our being.",

    description:
      "In this artwork, the colors and shapes merge to create a sense of movement and emotion.",

    availability: "unavailable",

    price: {
      amount: 500,
      currency: "USD",
    },
  },

  {
    id: "yasemi_iii",

    slug: "yasemi-iii",

    title: "Yasemi III",

    year: 2026,

    creationStatus: "planned",

    authorship: "original",

    context: "independent",

    medium: "oil",

    support: "canvas",

    categories: [
      "figurative",
      "spiritual",
    ],

    seriesId: "yasemi",

    dimensions: {
      width: 40,
      height: 30,
      unit: "cm",
    },
    images: {
      primary: {
        src: "/artworks/yasemi_III.webp",
        alt: "Yasemi III by Rolando Del Carmen",
        width: 888,
        height: 592,
      },
    },

    quote:
      "She sleeps in the water, awake in the air.",

    description:
      "Yasemi, the seed that sleeps in the water and wakes in the air. The piece has three distinct sections: the darkness of the water at the bottom, the light of the air at the top, and the transition zone in between where Yasemi rests.",

    availability: "unavailable",

    price: {
      amount: 500,
      currency: "USD",
    },
  },

  {
    id: "yasemi_iv",

    slug: "yasemi-iv",

    title: "Yasemi IV",

    year: 2026,

    creationStatus: "planned",

    authorship: "original",

    context: "independent",

    medium: "oil",

    support: "canvas",

    categories: [
      "figurative",
      "spiritual",
    ],

    seriesId: "yasemi",

    dimensions: {
      width: 40,
      height: 30,
      unit: "cm",
    },
    images: {
      primary: {
        src: "/artworks/yasemi_IV.webp",
        alt: "Yasemi IV by Rolando Del Carmen",
        width: 888,
        height: 592,
      },
    },

    quote:
      "More brilliant each day, no longer a seed but a flower in the air.",

    description:
      "The seed blooms and becomes a flower, spreading its brilliance day by day. She is in the air, with her colors, her light, her joy, her movement.",

    availability: "unavailable",

    price: {
      amount: 500,
      currency: "USD",
    },
  },
  {
    id: "selenia_de_maria",

    slug: "selenia_de_maria",

    title: "Selenia de María",

    year: 2022,

    creationStatus: "completed",

    authorship: "original",

    context: "commission",

    medium: "charcoal",

    support: "tonal paper Strathmore",

    categories: [
      "portrait",
      "spiritual",
    ],

    dimensions: {
      width: 54,
      height: 44,
      unit: "cm",
    },
    images: {
      primary: {
        src: "/artworks/selenia_de_maria.webp",
        alt: "Selenia de Maria by Rolando Del Carmen",
        width: 1080,
        height: 810,
      },
    },

    quote:
      "Artwork taken from a customer photograph. Marriage portrait.",

    description:
      "Artwork created taking as reference a photography. It is a customer order. Client took the photo on cellphone. It was retouched on photoshop to increase the contrast and using a AI program to improve the quality of the photo face.",

    availability: "sold",

    price: {
      amount: 700,
      currency: "USD",
    },
  },
  {
    id: "la_chercheuse",

    slug: "la_chercheuse",

    title: "Busto de Bevedere - Chercheuse",

    year: 2021,

    creationStatus: "completed",

    authorship: "original",

    context: "independent",

    medium: "oil",

    support: "canvas",

    categories: [
      "still-life",
      "figurative",
      "cast",
      "classic",
      "study",
      "academic"
    ],

    seriesId: "the_discipline_of_seeing",

    dimensions: {
      width: 50,
      height: 60,
      unit: "cm",
    },

    images: {
      primary: {
        src: "/artworks/la_chercheuse.webp",
        alt: "Busto de Bevedere - Chercheuse by Rolando Del Carmen",
        width: 3072,
        height: 4096,
      },
    },

    quote:
      "Original cast artwork.",

    description:
      "Original cast artwork created entirely by observation.",

    availability: "available",

    price: {
      amount: 680,
      currency: "USD",
    },
  },
  {
    id: "carga_tu_propia_cruz",

    slug: "carga_tu_propia_cruz",

    title: "Carga tu Propia Cruz",

    year: 2022,

    creationStatus: "completed",

    authorship: "original",

    context: "independent",

    medium: "oil",

    support: "canvas",

    categories: [
      "figurative",
      "contemporary",
      "study",
      "symbolic",
      "spiritual",
      "nude",
    ],

    dimensions: {
      width: 39,
      height: 54,
      unit: "cm",
    },

    images: {
      primary: {
        src: "/artworks/carga_tu_propia_cruz.webp",
        alt: "Carga tu Propia Cruz by Rolando Del Carmen",
        width: 3072,
        height: 4096,
      },
    },

    quote:
      "Artwork taken from internet de Ross Spirou.",

    description:
      "Copy artwork created taking as reference a photo. Using as a study of tonal values and temperature and grisaille underpainting. It was retouched by photoshop",

    availability: "available",

    price: {
      amount: 450,
      currency: "USD",
    },
  },

  {
    id: "cloe",

    slug: "cloe",

    title: "Cloe - La Vaquita",

    year: 2019,

    creationStatus: "completed",

    authorship: "original",

    context: "independent",

    medium: "oil",

    support: "canvas",

    categories: [
      "figurative",
      "contemporary",
      "study",
      "symbolic",
      "animal-lover",
    ],

    dimensions: {
      width: 30,
      height: 30,
      unit: "cm",
    },

    images: {
      primary: {
        src: "/artworks/cloe.webp",
        alt: "Cloe - La Vaquita by Rolando Del Carmen",
        width: 3071,
        height: 3071,
      },
    },

    quote:
      "There is always magic with inspiration and imagination.",

    description:
      "Painting using the imagination and images as inspiration. Retouched on photoshop. It was painting for an exhibition in a vegetarian restaurant.",

    availability: "available",

    price: {
      amount: 400,
      currency: "USD",
    },
  },

  {
    id: "flor_del_desierto",

    slug: "flor-del-desierto",

    title: "Flor del Desierto",

    year: 2019,

    creationStatus: "completed",

    authorship: "original",

    context: "independent",

    medium: "oil",

    support: "canvas",

    categories: [
      "figurative",
      "contemporary",
      "study",
      "symbolic",
      "impasto",
    ],

    dimensions: {
      width: 40,
      height: 50,
      unit: "cm",
    },

    images: {
      primary: {
        src: "/artworks/flor_del_desierto.webp",
        alt: "Flor del Desierto by Rolando Del Carmen",
        width: 3071,
        height: 3071,
      },
    },

    quote:
      "All start alone, but we can't stay without a company even in the desert.",

    description:
      "The desert is a place where we can find ourselves, but we need the company of others to grow. A friend once told me that the flowers in the desert are the most beautiful because they have to fight to survive.",

    availability: "available",

    price: {
      amount: 450,
      currency: "USD",
    },
  },

  {
    id: "flor_francesa",

    slug: "flor_francesa",

    title: "Flor Francesa",

    year: 2022,

    creationStatus: "completed",

    authorship: "original",

    context: "independent",

    medium: "oil",

    support: "canvas",

    categories: [
      "still-life",
      "figurative",
      "study",
      "academic",
    ],

    dimensions: {
      width: 30,
      height: 40,
      unit: "cm",
    },

    images: {
      primary: {
        src: "/artworks/flor_francesa.webp",
        alt: "Flor Francesa by Rolando Del Carmen",
        width: 2159,
        height: 2717,
      },
    },

    quote:
      "Experimenting allaprima and painting a rose in a day",

    description:
      "studying the light and colors of the petals, an aproximation to the impressionist painting.",

    availability: "available",

    price: {
      amount: 200,
      currency: "USD",
    },
  },
  {
    id: "franko",

    slug: "franko",

    title: "Franko En Día De Campo",

    year: 2020,

    creationStatus: "completed",

    authorship: "original",

    context: "commission",

    medium: "charcoal",

    support: "tonal paper Strathmore",

    categories: [
      "figurative",
      "portrait",
      "study",
    ],

    dimensions: {
      width: 44,
      height: 54,
      unit: "cm",
    },

    images: {
      primary: {
        src: "/artworks/franko.webp",
        alt: "Franko En Día De Campo by Rolando Del Carmen",
        width: 720,
        height: 908,
      },
    },

    quote:
      "Artwork taken from a customer photo.",

    description:
      "Copy artwork created taking as reference a photo. His son was in the a camping sunny day. It was retouched by photoshop.",

    availability: "sold",

    price: {
      amount: 500,
      currency: "USD",
    },
  },
  {
    id: "la_plancha",

    slug: "la_plancha",

    title: "La Plancha",

    year: 2022,

    creationStatus: "completed",

    authorship: "original",

    context: "commission",

    medium: "oil",

    support: "canvas",

    categories: [
      "figurative",
      "still-life",
      "study",
      "academic",
    ],

    dimensions: {
      width: 35,
      height: 45,
      unit: "cm",
    },

    images: {
      primary: {
        src: "/artworks/la_plancha.webp",
        alt: "La Plancha by Rolando Del Carmen",
        width: 3072,
        height: 4096,
      },
    },

    quote:
      "First still life painting from my life.",

    description:
      "First still life painting and project of my life. Created by observation using limited palette.",

    availability: "sold",

    price: {
      amount: 1200,
      currency: "USD",
    },
  },

  {
    id: "el_pie",

    slug: "el_pie",

    title: "El Pie",

    year: 2020,

    creationStatus: "completed",

    authorship: "original",

    context: "independent",

    medium: "oil",

    support: "canvas",

    categories: [
      "figurative",
      "still-life",
      "study",
      "cast",
      "classic",
      "academic",
    ],

    // seriesId: "the_discipline_of_seeing",

    dimensions: {
      width: 40,
      height: 30,
      unit: "cm",
    },

    images: {
      primary: {
        src: "/artworks/el_pie.webp",
        alt: "El Pie by Rolando Del Carmen",
        width: 720,
        height: 716,
      },
    },

    quote:
      "Original cast artwork. Created by observation.",

    description:
      "Original cast artwork created by observation. Created by observation using limited palette.",

    availability: "reserved",

    price: {
      amount: 480,
      currency: "USD",
    },
  },

  {
    id: "la_donna_velata",

    slug: "la_donna_velata",

    title: "La Donna Velata",

    year: 2021,

    creationStatus: "completed",

    authorship: "master-copy",

    context: "academic-study",

    medium: "oil",

    support: "canvas",

    categories: [
      "figurative",
      "study",
      "academic",
      "portrait",
    ],

    dimensions: {
      width: 60,
      height: 76,
      unit: "cm",
    },

    images: {
      primary: {
        src: "/artworks/la_donna_velata.webp",
        alt: "La Donna Velata by Rolando Del Carmen",
        width: 3072,
        height: 4096,
      },
    },

    quote:
      "Master copy study using limited palette by Rafael Sanzio.",

    description:
      "Copy of La Donna Velata from Rafael Sanzio. Study of light, color and technique of the Renaissance master.",

    availability: "available",

    price: {
      amount: 1500,
      currency: "USD",
    },
  },

  {
    id: "margarita_la_niña",

    slug: "margarita_la_nina",

    title: "Margarita la Niña",

    year: 2022,

    creationStatus: "completed",

    authorship: "master-copy",

    context: "academic-study",

    medium: "charcoal",

    support: "tonal paper Strathmore",

    categories: [
      "figurative",
      "portrait",
      "study",
    ],

    dimensions: {
      width: 60,
      height: 76,
      unit: "cm",
    },

    images: {
      primary: {
        src: "/artworks/margarita_la_nina.webp",
        alt: "Margarita la Niña by Rolando Del Carmen",
        width: 3072,
        height: 4096,
      },
    },

    quote:
      "Copy artwork of innocence.",

    description:
      "Artwork copy study of tonal values, always wanted to draw a little girl.",

    availability: "available",

    price: {
      amount: 450,
      currency: "USD",
    },
  },

  {
    id: "el_desnudo_masculino",

    slug: "el_desnudo_masculino",

    title: "El Desnudo Masculino",

    year: 2017,

    creationStatus: "completed",

    authorship: "study-after",

    context: "academic-study",

    medium: "graphite",

    support: "tonal paper Canson",

    categories: [
      "nude",
      "portrait",
      "study",
    ],

    dimensions: {
      width: 30,
      height: 39,
      unit: "cm",
    },

    images: {
      primary: {
        src: "/artworks/el_desnudo_masculino.webp",
        alt: "El Desnudo Masculino by Rolando Del Carmen",
        width: 963,
        height: 1069,
      },
    },

    quote:
      "Copy artwork study and documentation.",

    description:
      "It was created taking as reference a photography. It is a copy as practice. First full body nude drawing without training.",

    availability: "available",

    price: {
      amount: 380,
      currency: "USD",
    },
  },

  {
    id: "desnudo_joven",

    slug: "desnudo_joven",

    title: "Desnudo Joven",

    year: 2018,

    creationStatus: "completed",

    authorship: "master-copy",

    context: "academic-study",

    medium: "charcoal",

    support: "tonal paper Strathmore",

    categories: [
      "nude",
      "portrait",
      "study",
      "academic",
    ],

    dimensions: {
      width: 50,
      height: 60,
      unit: "cm",
    },

    images: {
      primary: {
        src: "/artworks/desnudo_joven.webp",
        alt: "Desnudo Joven by Rolando Del Carmen",
        width: 674,
        height: 731,
      },
    },

    quote:
      "First charcoal drawing project.",

    description:
      "First charcoal drawing project. Study from a lithography taking as reference a photo print.",

    availability: "available",

    price: {
      amount: 450,
      currency: "USD",
    },
  },

  {
    id: "parthenon",

    slug: "parthenon",

    title: "Parthenon",

    year: 2017,

    creationStatus: "completed",

    authorship: "master-copy",

    context: "academic-study",

    medium: "graphite",

    support: "tonal paper Canson",

    categories: [
      "lithography",
      "bargue",
      "study",
      "academic",
    ],

    seriesId: "the_discipline_of_seeing",

    dimensions: {
      width: 45,
      height: 30,
      unit: "cm",
    },

    images: {
      primary: {
        src: "/artworks/parthenon.webp",
        alt: "Parthenon by Rolando Del Carmen",
        width: 1200,
        height: 896,
      },
    },

    quote:
      "Bargue lithography study.",

    description:
      "Bargue lithography copy from the book Bargue's Course Drawing.",

    availability: "available",

    price: {
      amount: 210,
      currency: "USD",
    },
  },

  {
    id: "hugh_jackman",

    slug: "hugh_jackman",

    title: "Hugh Jackman",

    year: 2017,

    creationStatus: "completed",

    authorship: "study-after",

    context: "academic-study",

    medium: "graphite",

    support: "tonal paper Canson",

    categories: [
      "portrait",
      "study",
      "academic",
    ],

    dimensions: {
      width: 27,
      height: 31,
      unit: "cm",
    },

    images: {
      primary: {
        src: "/artworks/hugh_jackman.webp",
        alt: "Hugh Jackman by Rolando Del Carmen",
        width: 720,
        height: 707,
      },
    },

    quote:
      "Les miserables the movie nostalgia scene",

    description:
      "First project of a portrait of my life. Portrait of an actor Hugh Jackman. It was created taking as reference a photography .It is a copy as practice. ",

    availability: "available",

    price: {
      amount: 340,
      currency: "USD",
    },
  },

  {
    id: "torso_de_bevedere",

    slug: "torso_de_bevedere",

    title: "Le Torse du Belvédère",

    year: 2018,

    creationStatus: "completed",

    authorship: "study-after",

    context: "academic-study",

    medium: "graphite",

    support: "tonal paper Canson",

    categories: [
      "study",
      "academic",
      "cast",
      "bargue",
      "lithography",
    ],

    seriesId: "the_discipline_of_seeing",

    dimensions: {
      width: 34,
      height: 50,
      unit: "cm",
    },

    images: {
      primary: {
        src: "/artworks/torso_de_bevedere.webp",
        alt: "Torso de Bevedere by Rolando Del Carmen",
        width: 720,
        height: 721,
      },
    },

    quote:
      "Study from a Bargue lithography",

    description:
      "Bargue lithography copy from the book Bargue's Course Drawing.",

    availability: "reserved",

    price: {
      amount: 260,
      currency: "USD",
    },
  },

  {
    id: "la_mechuda",

    slug: "la_mechuda",

    title: "La Mechuda",

    year: 2018,

    creationStatus: "completed",

    authorship: "study-after",

    context: "academic-study",

    medium: "charcoal",

    support: "tonal paper Strathmore",

    categories: [
      "study",
      "portrait",
      "symbolic",
    ],

    dimensions: {
      width: 41,
      height: 56,
      unit: "cm",
    },

    images: {
      primary: {
        src: "/artworks/la_mechuda.webp",
        alt: "La Mechuda by Rolando Del Carmen",
        width: 720,
        height: 726,
      },
    },

    quote:
      "Copy artwork study.",

    description:
      "My sister feelings embodied in the picture. She is all the time crazy and worried. She doesn't take care of herself of the outfit. But with a heart of justice and compasion love. It was created taking as reference a photography. It is a copy as practice.",

    availability: "reserved",

    price: {
      amount: 260,
      currency: "USD",
    },
  },

  {
    id: "la_travesti",

    slug: "la_travesti",

    title: "La Travesti",

    year: 2017,

    creationStatus: "completed",

    authorship: "study-after",

    context: "academic-study",

    medium: "charcoal",

    support: "tonal paper Strathmore",

    categories: [
      "study",
      "portrait",
      "symbolic",
    ],

    dimensions: {
      width: 45,
      height: 60,
      unit: "cm",
    },

    images: {
      primary: {
        src: "/artworks/la_travesti.webp",
        alt: "La Travesti by Rolando Del Carmen",
        width: 670,
        height: 740,
      },
    },

    quote:
      "Copy artwork study.",

    description:
      "My sister is a professional in nails and she reflect fashion and good looking, quiet and intelligent as skills of her. It was created taking as reference a photography. It is a copy as practice.",

    availability: "reserved",

    price: {
      amount: 260,
      currency: "USD",
    },
  },

  {
    id: "juan_carlillos",

    slug: "juan_carlillos",

    title: "Juan Carlillos",

    year: 2017,

    creationStatus: "completed",

    authorship: "original",

    context: "commission",

    medium: "charcoal",

    support: "tonal paper Strathmore",

    categories: [
      "study",
      "portrait",
      "symbolic",
    ],

    dimensions: {
      width: 45,
      height: 60,
      unit: "cm",
    },

    images: {
      primary: {
        src: "/artworks/juan_carlillos.webp",
        alt: "Juan Carlillos by Rolando Del Carmen",
        width: 953,
        height: 1080,
      },
    },

    quote:
      "Artwork taken from a customer photo.",

    description:
      "Copy artwork created taking as reference a photo. Customer order of his photo when he was a baby. His babe looks like him. It was a gift. It was retouched by photoshop.",

    availability: "reserved",

    price: {
      amount: 1000,
      currency: "USD",
    },
  },

  {
    id: "victoria_de_samotracia",

    slug: "victoria-de-samotracia",

    title: "Victoria de Samotracia",

    year: 2019,

    creationStatus: "completed",

    authorship: "original",

    context: "commission",

    medium: "graphite",

    support: "tonal paper Canson",

    categories: [
      "study",
      "cast",
      "symbolic",
    ],

    seriesId: "the_discipline_of_seeing",

    dimensions: {
      width: 45,
      height: 60,
      unit: "cm",
    },

    images: {
      primary: {
        src: "/artworks/victoria_de_samotracia.webp",
        alt: "Victoria de Samotracia by Rolando Del Carmen",
        width: 720,
        height: 741,
      },
    },

    quote:
      "Artwork taken from a customer photo.",

    description:
      "Artwork created taking as reference a photography. It is a customer order. Client took the photo in the Museum du Louvre, French. First work sold.",

    availability: "sold",

    price: {
      amount: 500,
      currency: "USD",
    },
  },

  {
    id: "desnudo_ronald_tellini",

    slug: "desnudo-ronald-tellini",

    title: "Desnudo Ronald Tellini",

    year: 2017,

    creationStatus: "completed",

    authorship: "original",

    context: "commission",

    medium: "charcoal",

    support: "tonal paper Strathmore",

    categories: [
      "study",
      "portrait",
      "symbolic",
      "nude",
    ],

    dimensions: {
      width: 45,
      height: 68,
      unit: "cm",
    },

    images: {
      primary: {
        src: "/artworks/desnudo_ronald_tellini.webp",
        alt: "Desnudo Ronald Tellini by Rolando Del Carmen",
        width: 1080,
        height: 1345,
      },
    },

    quote:
      "Artwork taken from a customer photo.",

    description:
      "Artwork created taking as reference a photography. It is a customer order. Client took the photo session and it was retouched on photoshop to increase the contrast. Second work sell.",

    availability: "sold",

    price: {
      amount: 500,
      currency: "USD",
    },
  },

  {
    id: "actriz_vivian_leigh",

    slug: "actriz-vivian-leigh",

    title: "Actriz Vivian Leigh",

    year: 2019,

    creationStatus: "completed",

    authorship: "study-after",

    context: "academic-study",

    medium: "charcoal",

    support: "tonal paper Strathmore",

    categories: [
      "study",
      "portrait",
      "symbolic",
    ],

    dimensions: {
      width: 31,
      height: 44,
      unit: "cm",
    },

    images: {
      primary: {
        src: "/artworks/actriz_vivian_leigh.webp",
        alt: "Actriz Vivian Leigh by Rolando Del Carmen",
        width: 720,
        height: 722,
      },
    },

    quote:
      "Artwork copy from an actress.",

    description:
      "Copy artwork just because I liked and it happened something curious, the final result it was a similar photo from my grandmother which I have never knew using the same haircut and same pose.",

    availability: "reserved",

    price: {
      amount: 500,
      currency: "USD",
    },
  },
  {
    id: "mama_de_luis_alonso",

    slug: "mama-de-luis-alonso",

    title: "Mama de Luis Alonso",

    year: 2022,

    creationStatus: "completed",

    authorship: "original",

    context: "commission",

    medium: "graphite",

    support: "tonal paper Canson",

    categories: [
      "study",
      "portrait",
      "symbolic",
    ],

    dimensions: {
      width: 21,
      height: 29,
      unit: "cm",
    },

    images: {
      primary: {
        src: "/artworks/mama_de_luis_alonso.webp",
        alt: "Mama de Luis Alonso by Rolando Del Carmen",
        width: 1080,
        height: 1956,
      },
    },

    quote:
      "Artwork taken from a customer photo.",

    description:
      "Passport photo retouched using also Photoshop and AI program to have better quality definition",

    availability: "reserved",

    price: {
      amount: 250,
      currency: "USD",
    },
  },
  {
    id: "el_pitufino_coral",

    slug: "el-pitufino-coral",

    title: "El Pitufino Coral",

    year: 2020,

    creationStatus: "completed",

    authorship: "study-after",

    context: "independent",

    medium: "graphite",

    support: "using color pencils",

    categories: [
      "study",
      "portrait",
      "symbolic",
    ],

    dimensions: {
      width: 61,
      height: 68,
      unit: "cm",
    },

    images: {
      primary: {
        src: "/artworks/el_pitufino_coral.webp",
        alt: "El Pitufino Coral by Rolando Del Carmen",
        width: 720,
        height: 719,
      },
    },

    quote:
      "Artwork taken from a photo from the internet.",

    description:
      "serpent inspriation with color pencils. it was used special paper to draw with color pencils. his eyes attract attention of the viewer.  ",

    availability: "available",

    price: {
      amount: 500,
      currency: "USD",
    },
  },

  {
    id: "retrato_de_mujer",

    slug: "retrato-de-mujer",

    title: "Retrato de Mujer",

    year: 2024,

    creationStatus: "completed",

    authorship: "master-copy",

    context: "academic-study",

    medium: "oil",

    support: "canvas",

    categories: [
      "study",
      "portrait",
      "figurative",
      "symbolic",
      "academic",
    ],

    dimensions: {
      width: 55,
      height: 40,
      unit: "cm",
    },

    images: {
      primary: {
        src: "/artworks/retrato_de_mujer.webp",
        alt: "Retrato de Mujer by Rolando Del Carmen",
        width: 2250,
        height: 4000,
      },
    },

    quote:
      "Master copy from a study of Alejandro Roosembelt ",

    description:
      "Master copy study with the artist Alejandro Roosembelt. His works were an inspiration to me. It was an honor to make a copy of his work.",

    availability: "available",

    price: {
      amount: 500,
      currency: "USD",
    },
  },

  {
    id: "l_Aurore",

    slug: "l-aurore",

    title: "L'Aurore",

    year: 2025,

    creationStatus: "completed",

    authorship: "master-copy",

    context: "academic-study",

    medium: "oil",

    support: "canvas",

    categories: [
      "study",
      "portrait",
      "symbolic",
      "academic",
      "nude",
    ],

    dimensions: {
      width: 113,
      height: 133,
      unit: "cm",
    },

    images: {
      primary: {
        src: "/artworks/l_aurore.webp",
        alt: "L'Aurore by Rolando Del Carmen",
        width: 2222,
        height: 2824,
      },
    },

    quote:
      "Master copy from a study of Abel León Uurivilca ",

    description:
      "Master copy study with the artist Abel León Uurivilca. His works has been an inspiration to me.",

    availability: "available",

    price: {
      amount: 1500,
      currency: "USD",
    },
  },

  {
    id: "psyche_de_naples",

    slug: "psyche_de_naples",

    title: "Psyché de Náples",

    year: 2017,

    creationStatus: "completed",

    authorship: "study-after",

    context: "academic-study",

    medium: "graphite",

    support: "tonal paper Canson",

    seriesId: "the_discipline_of_seeing",

    categories: [
      "study",
      "lithography",
      "academic",
      "bargue",
    ],

    dimensions: {
      width: 113,
      height: 133,
      unit: "cm",
    },

    images: {
      primary: {
        src: "/artworks/psyche_de_naples.webp",
        alt: "Psyché de Náples by Rolando Del Carmen",
        width: 979,
        height: 1067,
      },
    },

    quote:
      "Artwork study",

    description:
      "Lithography study of the Psyche de Naples sculpture from academic course of Charles Bargue.",

    availability: "available",

    price: {
      amount: 150,
      currency: "USD",
    },
  },
  {
    id: "homenaje_postumo",

    slug: "homenaje_postumo",

    title: "Homenaje Postumo",

    year: 2021,

    creationStatus: "completed",

    authorship: "original",

    context: "commission",

    medium: "graphite",

    support: "tonal paper Canson",

    categories: [
      "study",
      "portrait",
      "symbolic",
    ],

    dimensions: {
      width: 13,
      height: 28,
      unit: "cm",
    },

    images: {
      primary: {
        src: "/artworks/homenaje_postumo.webp",
        alt: "Homenaje Postumo by Rolando Del Carmen",
        width: 1080,
        height: 1080,
      },
    },

    quote:
      "Drawing for a commission of a deceased friend.",

    description:
      "It was a commission made for a friend to honor his deceased friend.",

    availability: "sold",

    price: {
      amount: 340,
      currency: "USD",
    },
  },

  {
    id: "gatito",

    slug: "gatito",

    title: "Gatito",

    year: 2021,

    creationStatus: "completed",

    authorship: "study-after",

    context: "independent",

    medium: "oil",

    support: "canvas",

    categories: [
      "study",
      "animal-lover",
    ],

    dimensions: {
      width: 30,
      height: 30,
      unit: "cm",
    },

    images: {
      primary: {
        src: "/artworks/gatito.webp",
        alt: "Gatito by Rolando Del Carmen",
        width: 1080,
        height: 1067,
      },
    },

    quote:
      "Painting artwork taken from a photo from the internet.",

    description:
      "Painting artwork using oil colors on canvas as formal way of personal documentation.",

    availability: "reserved",

    price: {
      amount: 240,
      currency: "USD",
    },
  },
];