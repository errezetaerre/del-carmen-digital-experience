import { useTranslations } from "next-intl";
import Link from "@/i18n/navigation";
import { Container } from "@/shared/layout/container";
import AboutContinueMotion from "./AboutContinueMotion";

export default function AboutContinue() {
    const t = useTranslations("About");


    return (
        <section className="about-continue-scene relative overflow-hidden bg-neutral-950 py-28 md:py-36 lg:py-40">
            <Container>
                <div className="about-continue-motion">
                    <div className="max-w-3xl">
                        <p className="about-continue-eyebrow font-sans text-[10px] uppercase tracking-[0.34em] text-brand-gold/70">
                            {t("continue.eyebrow")}
                        </p>

                        <h2 className="about-continue-heading mt-5 font-display text-5xl font-light leading-[0.95] tracking-[-0.03em] text-stone-100 md:text-6xl lg:text-7xl">
                            {t("continue.titleFirst")}
                            <span className="block italic text-stone-500">{t("continue.titleSecond")}</span>
                        </h2>
                    </div>

                    <div className="about-continue-pathways mt-16 grid border-t border-white/[0.08] md:mt-20 md:grid-cols-2">
                        <Link
                            href="/artist"
                            className="about-continue-path group relative border-b border-white/[0.08] py-10 md:border-r md:py-12"
                        >
                            <div className="about-continue-line absolute left-0 top-0 h-px w-full origin-left bg-brand-gold/60" />

                            <div className="md:pr-10">
                                <p className="font-sans text-[9px] uppercase tracking-[0.3em] text-brand-gold/65">
                                    01
                                </p>

                                <h3 className="about-continue-title mt-4 font-display text-3xl font-light text-stone-100 transition-colors duration-500 group-hover:text-brand-gold md:text-4xl">
                                    {t("continue.artist")}
                                </h3>

                                <p className="about-continue-copy mt-4 max-w-sm font-sans text-sm font-light leading-6 text-stone-500">
                                    {t("continue.artistDescription")}
                                </p>

                                <span className="about-continue-arrow mt-7 inline-block font-sans text-lg text-stone-500 transition duration-500 group-hover:translate-x-2 group-hover:text-brand-gold">
                                    →
                                </span>
                            </div>
                        </Link>

                        <Link
                            href="/artworks"
                            className="about-continue-path group relative border-b border-white/[0.08] py-10 md:pl-10 md:py-12"
                        >
                            <div className="about-continue-line absolute left-0 top-0 h-px w-full origin-left bg-brand-gold/60" />

                            <div>
                                <p className="font-sans text-[9px] uppercase tracking-[0.3em] text-brand-gold/65">
                                    02
                                </p>

                                <h3 className="about-continue-title mt-4 font-display text-3xl font-light text-stone-100 transition-colors duration-500 group-hover:text-brand-gold md:text-4xl">
                                    {t("continue.artworks")}
                                </h3>

                                <p className="about-continue-copy mt-4 max-w-sm font-sans text-sm font-light leading-6 text-stone-500">
                                    {t("continue.artworksDescription")}
                                </p>

                                <span className="about-continue-arrow mt-7 inline-block font-sans text-lg text-stone-500 transition duration-500 group-hover:translate-x-2 group-hover:text-brand-gold">
                                    →
                                </span>
                            </div>
                        </Link>
                    </div>
                </div>
            </Container>

            <AboutContinueMotion />
        </section>
    );
}
