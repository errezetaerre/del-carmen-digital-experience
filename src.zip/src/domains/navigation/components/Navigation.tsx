"use client";

import Link from "@/i18n/navigation";
import { usePathname } from "@/i18n/navigation";
import { useState } from "react";
import { useTranslations } from "next-intl";
import LanguageSwitcher from "@/i18n/LanguageSwitcher";

import { useNavigationScroll } from "../hooks";
import { Container } from "@/shared/layout";
import { brand } from "@/config/brand";
import {
  NAVIGATION_ITEMS,
} from "../constants";
import MobileMenu from "./MobileMenu";
import { isNavigationItemActive } from "../utils/isNavigationItemActive";

export default function Navigation() {
  const t = useTranslations("Navigation");
  const pathname = usePathname();
  const isScrolled = useNavigationScroll();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);


  const headerState = isScrolled
    ? "bg-foreground/90 backdrop-blur-md shadow-sm"
    : "bg-transparent";

  return (
    <>
      <header
        className={[
          "fixed inset-x-0 top-0 z-50 transition-all duration-500",
          headerState,
        ].join(" ")}
      >
        <Container className="flex h-[64px] items-center justify-between">
          {/* Brand */}
          <Link
            href="/"
            className={[
              "text-base font-light uppercase tracking-[0.30em] transition-opacity duration-300 hover:opacity-80",
              isScrolled
                ? "text-brand-gold/100"
                : "text-white",
            ].join(" ")}
          >
            <span>{brand.name}</span>

            <span className="block text-[11px] tracking-[0.28em] text-brand-gold">
              by {brand.parentBrand}
            </span>
          </Link>

          {/* Desktop / Tablet Navigation */}
          <nav className="hidden lg:block" aria-label={t("main")}>
            <ul className="flex items-center gap-12">
              {NAVIGATION_ITEMS.map((item) => {
                const isActive =
                  isNavigationItemActive(
                    pathname,
                    item.href,
                  );

                return (
                  <li key={item.href}>
                    {isActive && pathname === item.href ? (
                      <span
                        aria-current="page"
                        className="
                          cursor-default
                          text-sm
                          font-medium
                          uppercase
                          tracking-[0.12em]
                          text-brand-gold
                        "
                      >
                        {t(item.key)}
                      </span>
                    ) : (
                      <Link
                        href={item.href}
                        className={[
                          "text-sm uppercase tracking-[0.12em] transition-colors duration-300",

                          isActive
                            ? "font-medium text-brand-gold"
                            : isScrolled
                              ? "text-[#2F2E2C]/75 hover:text-brand-gold"
                              : "text-white/65 hover:text-white",
                        ].join(" ")}
                      >
                        {t(item.key)}
                      </Link>
                    )}
                  </li>
                );
              })}
            </ul>
          </nav>

          {/* Desktop / Tablet Language */}
          <LanguageSwitcher
            className={[
              "hidden text-sm uppercase tracking-[0.12em] transition-colors duration-300 lg:block",
              isScrolled
                ? "text-[#2F2E2C]/75 hover:text-brand-gold"
                : "text-white/65 hover:text-white",
            ].join(" ")}
          />

          {/* Mobile Menu Trigger */}
          <button
            type="button"
            onClick={() => setIsMobileMenuOpen(true)}
            aria-label={t("openMenu")}
            aria-expanded={isMobileMenuOpen}
            aria-controls="mobile-navigation"
            className={[
              "flex h-10 w-10 items-center justify-center lg:hidden",
              isScrolled
                ? "text-[#2F2E2C]"
                : "text-white",
            ].join(" ")}
          >
            <span className="sr-only">{t("openMenu")}</span>

            <span className="flex w-5 flex-col gap-[5px]">
              <span className="h-px w-full bg-current" />
              <span className="h-px w-full bg-current" />
              <span className="h-px w-full bg-current" />
            </span>
          </button>
        </Container>
      </header>

      <MobileMenu
        isOpen={isMobileMenuOpen}
        onClose={() => setIsMobileMenuOpen(false)}
      />
    </>
  );
}
