"use client";

import type { Artwork } from "@/domains/artworks";
import { KineticCarousel } from "@/shared/ui/kinetic-carousel";

import CollectionPreviewArtwork from "./CollectionPreviewArtwork";
import styles from "./CollectionPreviewWorks.module.css";
import { useTranslations } from "next-intl";

interface CollectionPreviewWorksProps {
    artworks: Artwork[];
    seriesSlug: string;
}

const VISIBLE_ARTWORKS = 4;

export default function CollectionPreviewWorks({
    artworks,
    seriesSlug,
}: CollectionPreviewWorksProps) {
    const t = useTranslations("Series");
    if (artworks.length === 0) {
        return null;
    }

    const hasCarousel =
        artworks.length > VISIBLE_ARTWORKS;

    /*
     * ------------------------------------------------
     * STANDARD GRID
     * ------------------------------------------------
     *
     * 1–4 artworks keep the approved grid
     * geometry and bottom anchoring.
     */
    if (!hasCarousel) {
        return (
            <div
                className={`
                    ${styles.root}
                    group/works
                    relative
                    z-20
                    hidden
                    h-64
                    w-full
                    max-w-3xl
                    lg:block
                `}
            >
                <div
                    className="
                        absolute
                        inset-x-0
                        bottom-0
                    "
                >
                    <p
                        className="
                            mb-3
                            font-sans
                            text-[9px]
                            uppercase
                            tracking-[0.26em]
                            text-white/35
                        "
                    >
                        {t("worksInCollection")}
                    </p>
                    <div
                        className={`
                            ${styles.viewport}
                            grid
                            h-7
                            gap-2
                            ${artworks.length === 1
                                ? "grid-cols-[repeat(3,minmax(0,1fr))] [&>*]:col-start-2"
                                : "grid-cols-4"
                            }
    `}
                    >
                        {artworks.map((artwork) => (
                            <CollectionPreviewArtwork
                                key={artwork.id}
                                artwork={artwork}
                                seriesSlug={seriesSlug}
                            />
                        ))}
                    </div>
                </div>
            </div>
        );
    }

    /*
     * ------------------------------------------------
     * KINETIC CAROUSEL
     * ------------------------------------------------
     *
     * 5+ artworks use the shared kinetic engine.
     * The collection keeps its own editorial card
     * geometry and hover expansion.
     */
    return (
        <div
            className={`
                ${styles.root}
                group/works
                relative
                z-20
                hidden
                h-64
                w-full
                max-w-3xl
                lg:block
            `}
        >
            <div
                className="
                    absolute
                    inset-x-0
                    bottom-0
                "
            >
                <p
                    className="
                        mb-3
                        font-sans
                        text-[9px]
                        uppercase
                        tracking-[0.26em]
                        text-white/35
                    "
                >
                    {t("worksInCollection")}
                </p>

                <KineticCarousel
                    itemCount={artworks.length}
                    viewportClassName={`
                        ${styles.viewport}
                        h-7
                    `}
                    trackClassName="
                        h-full
                        gap-2
                    "
                    previousLabel={t("previousArtworks")}
                    nextLabel={t("nextArtworks")}
                    previousButtonClassName="
                        left-2
                        top-1/2
                        h-8
                        w-8
                        text-lg
                    "
                    nextButtonClassName="
                        right-2
                        top-1/2
                        h-8
                        w-8
                        text-lg
                    "
                >
                    {artworks.map((artwork) => (
                        <div
                            key={artwork.id}
                            className="
                                h-full
                                w-[11.625rem]
                                min-w-0
                                shrink-0
                                [&>a]:h-full
                                [&>a]:w-full
                            "
                        >
                            <CollectionPreviewArtwork
                                artwork={artwork}
                                seriesSlug={seriesSlug}
                            />
                        </div>
                    ))}
                </KineticCarousel>
            </div>
        </div>
    );
}
