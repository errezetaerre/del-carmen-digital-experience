import Image from "next/image";
import Link from "@/i18n/navigation";
import ArtworkBadges from "@/shared/ui/artwork/ArtworkBadges";
import ArtworkComingSoon from "@/shared/ui/artwork/ArtworkComingSoon";
import ArtworkLinkFeedback from "@/shared/ui/artwork/ArtworkLinkFeedback";
import { getArtworkPresentation } from "@/domains/artworks/presentation/getArtworkPresentation";
import { useLocale } from "next-intl";
import { localizeArtwork } from "@/i18n/artworkCopy";

import type { Artwork } from "@/domains/artworks";

interface CollectionPreviewArtworkProps {
    artwork: Artwork;
    seriesSlug: string;
}

export default function CollectionPreviewArtwork({
    artwork: sourceArtwork,
    seriesSlug,
}: CollectionPreviewArtworkProps) {
    const locale = useLocale();
    const artwork = localizeArtwork(sourceArtwork, locale);
    const image =
        artwork.images.collection ??
        artwork.images.thumbnail ??
        artwork.images.primary;

    return (
        <Link
            href={`/series/${seriesSlug}?artwork=${encodeURIComponent(
                artwork.slug,
            )}`}
            className="
                group/artwork
                relative
                block
                h-full
                min-h-0
                min-w-0
                overflow-hidden
            "
        >
            <div
                className="
                    relative
                    h-full
                    w-full
                    overflow-hidden
                    bg-white/[0.03]
                "
            >
                {artwork.creationStatus !== "completed" ? <ArtworkComingSoon artwork={artwork} variant="thumbnail" imageSizes="18vw" /> : <Image
                    src={image.src}
                    alt={image.alt}
                    fill
                    sizes="18vw"
                    className="
                        object-cover
                        transition-transform
                        duration-700
                        ease-out

                        group-hover/artwork:scale-[1.025]
                        group-focus-within/artwork:scale-[1.025]
                    "
                />}

                <div
                    className="
                        absolute
                        inset-0
                        bg-gradient-to-t
                        from-black/65
                        via-transparent
                        to-transparent
                        opacity-0
                        transition-opacity
                        duration-500

                        group-hover/artwork:opacity-100
                        group-focus-within/artwork:opacity-100
                    "
                />

                <div
                    className="
                        absolute
                        inset-x-0
                        bottom-0
                        translate-y-3
                        px-4
                        pb-4
                        opacity-0
                        transition-all
                        duration-500

                        group-hover/artwork:translate-y-0
                        group-hover/artwork:opacity-100
                        group-focus-within/artwork:translate-y-0
                        group-focus-within/artwork:opacity-100
                    "
                >
                    <p
                        className="
                            font-display
                            text-lg
                            font-light
                            leading-none
                            text-white
                        "
                    >
                        {artwork.title}
                    </p>

                    <p
                        className="
                            mt-1
                            font-sans
                            text-[9px]
                            uppercase
                            tracking-[0.18em]
                            text-white/50
                        "
                    >
                        {getArtworkPresentation(artwork, locale).yearLabel}
                    </p>
                </div>
                <ArtworkBadges artwork={artwork} variant="thumbnail" passive />
                <ArtworkLinkFeedback overlay />
            </div>
        </Link>
    );
}
